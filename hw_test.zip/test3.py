x=2+3
y=4
y=-x+y+-input()
print y
