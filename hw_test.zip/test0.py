#randomly generated p0 AST

temp0 = (input())
print (input())
temp0 = (-25350)
input()
print (((-(-46643)) + (52922)) + (input()))
input()
print ((input()) + (-((input()) + (54453))))
(temp0) + (44224)
print (-12631)
T1 = (temp0)
#print all vars to ensure they are used at least once

print temp0
print T1