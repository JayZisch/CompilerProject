
#randomly generated p0 AST

- -4454 + 39121 + 18945
T0 = input()
T0 = input()
TMP1 = - 62522 + (- input())
TMP1 = T0 + 2701 + (TMP1)
T0 = input()
print - input() #test comment
-31991
T0 = T0
T0 = input()
print - input()
T0 = - (-26304)
T0 = TMP1
((((TMP1))) + - -62096 + input()) + T0 + input() + (TMP1) + (- - input() + 33417)  #test comment
print 56874 + T0
TMP1 = input()
TMP1
print - input()
T2 = input()
input()
T2 = TMP1
print - - ((input()))
print (- - (- T2 + T2))
TMP1 + - TMP1
TMP1 = - (-46706)
TMP1 = -6066
- (-2719) #test comment
TMP1 = 10664
-5529
tmp3 = TMP1
tmp3 + T0
t4 = 29552
Tmp5 = t4
print TMP1
print (-61666) + input() + - input() + (T0) + 12079
TMP6 = 23392
print -8338
Tmp5 = input()
input()
T2 = input() + -12611
print -34521
print input()
print 34127
input()
TMP6 = input()
T2
(-28045)
print input()
TMP1 = t4 + 27076 + - Tmp5
input()
print T0 + TMP6
tmp3 = (input())
print - input() + (-12598)
print - - - TMP1 + input() + (input())
print (input())
print (T2)
print - input()
print (31000)
t4 = T0
TMP6 = input()
((- - - 21383 + T0))
- TMP1
- input() + T0 + (TMP1 + (6638)) + -50919
 #test comment
print - input()
Temp7 = TMP6
print Temp7 + ((T2 + input())) + - (-13922)
TMP6 = (20655)
print 9500
TMP6 = 63134
print (input() + - (T2))
TMP6 = T2
TMP1 = t4
input()
t8 = - (tmp3) + - input()
print ((TMP6))
TMP1 = (t8 + Tmp5)
print -26587
print (TMP6)
print - input()
54
Temp9 = -33653
(input())
Temp9 = Temp9
 #test comment
print (-13586 + - input())
print input()
T0 = 61442
input()
print - ((tmp3 + (input()))) + - - input() + (T0) + input()
input()
temp10 = T0
print t4
T2
t8 = - (input()) + - (input()) + input()
print TMP6
-64043
print - -52218 + - input() + (temp10) + -58284 + t4
print 58193
- input() + - input()
TMP1 = - t8
print -33115
tmp3
print TMP1
- input()
input() + tmp3
Temp7 = input()
Tmp5 = input()
input()
Tmp5 = TMP6
- -16892
print ((- input()))
print T2
T0 = -61565
-60215
print -51480 + -947
-37160
Temp9 = t8
print input()
print (- -4087)
tmp3 = (input())
input()
input()
- ((TMP1)) #test comment
print (T0)
temp10 = - T0 + input()
TMP6
print - input()
Tmp5 = (input() + -7466)
print - TMP6
print TMP1
print input()
(-63929)
print -10542
Temp9
-5586
TMP6 = (3279)
- T0
(T2 + input())
t8 = -52221 + T2
- Tmp5
- (TMP6) + - 31375
- (t4 + input())
print -14620
t8 = Temp9 + 39394 + -11404 + input()
print T2
(T0)
-2912
32436
input()
t4 = input()
print (- temp10 + - (40815) + input() + - Tmp5 + - - 62770 + (Tmp5) + TMP1 + T2 + input())
-18634
Temp7 = input()
- 37279 + (- input())
input()
print tmp3
temp10 = -14806
Temp9 = -61662
print 11972
 #test comment
TMP6
print input()
T0 = t8
t4 = TMP1
Temp11 = Temp9 + - 19846
tmp3 + Temp11
print -33101
Temp11 + Tmp5 + (tmp3)
Temp7 = - Temp9
TMP1 = 18689
input()
TMP6 = t8
print (Temp11)
T0 = input()
temp10 = input()
print (T2) + Temp9 + tmp3 + input() + (input())
print t8
print - 58203 + (input()) + - - - -22896 + input() + - temp10 #test comment
print (input())
print - t4 + T2
tmp3 = input()
(input())
- (TMP6)
-53779
Temp7 = Temp9
t4 = ((- (TMP6))) + t8 + 18086
 #test comment
Tmp5
print T2
- Temp9 + - 7735
print ((TMP1))
- -26998
 #test comment
print input()
input() + input()
tmp12 = (-48099)
print ((- - input() + ((29710)) + -3641) + - - (- Temp11) + input()) #test comment
print input()
print (- t8 + (- - - input() + - ((TMP6))) + (Temp7) + (-20698)) #test comment
T0 = (Temp11)
print 49980
t8 = Temp7
- input() + input()
t8 = T2
print -26130
print 5677
print input()
Tmp5
print - input()
t8 = -31022
print input() + Temp11 + 47984
input()
print T2
print (tmp3)
print -836
print T2 + t8
-40498
-22227
print -8694 + (- tmp12)
(input())
input() + -26086 + (14757 + - (- input())) + tmp3 + - input()
print Temp9 + 56114
print TMP1
tmp3
print -28620
print tmp12
print Temp11
print - - (52256)
print TMP6
tmp3 = input()
print - - Temp7
tmp3 = (-32283) + (- input())
- (- (t8 + - - (- input()))) + Tmp5 + (-41391) + tmp12
print t8
t8 = Temp9
temp10 = (- 51658)
- input() + (t8) #test comment
 #test comment
Tmp5 = (((- input())))
TMP6 = (TMP6)
49350
print -13570
6263 + input()
Temp9 = t8
print - 38478
print ((input()))
print (Temp9)
Temp13 = input()
Temp7 = 35444 + input()
temp10
tmp12 = input()
- (((-18730)))
TMP1 = 33114
tmp14 = -51597
print input()
-8697
print - input()
input()
(- - Temp13)
print 52969
T2 + - ((-33489))
print ((t4) + input())
print - tmp14
- (tmp12)
- ((((- input() + input()))))
T2 = - (TMP1)
T0 = 41066 + (- -44802 + 47509) #test comment
t4 = - 34093
- - -20298
input()
tmp12 = - tmp14
print ((Temp13))
print (-40594)
print temp10
((- T2))
print - Tmp5 + input() + - input()
TMP1 = (- - 4632 + (TMP1) + -42252)
print input()
Temp13 = Temp7
Temp11 = (TMP1)
tmp14 = 24092
TMP6 = ((input()))
T0 = input()
print (T0)
(- - Tmp5)
print (-15542)
(-13484)
TMP1 = ((- (-6166 + - temp10 + - ((-23852 + (- - Temp13) + input() + (47822) + input() + input()) + -60949))))
Temp13 + -21196 + Temp9 #test comment

print - temp10 + (input() + Temp9) + (input())
Temp11 = temp10
TMP1 = input()
Temp7 = -6067
print input()
input() + (- input()) + - 7089
input() + (23006 + input())
input()
TMP15 = (-32900)
t8 = input() + input()
input()
25478
tmp12 = tmp3
-44836
46394
print -34068
print Temp11
18485
print - Tmp5 + input() + input() + 8896 + - input() + (44259 + - - Temp11 + temp10)
TMP1 = - TMP15
T2 = (input() + T0)
print T0
print ((-41836) + 51123) + (- -35276)
TMP15
- Tmp5
TMP1 = input() + - (TMP15)
print tmp14
input()
print T0
- t4
print input() + - - - - - -59131
29331
-32428
print input()
print input()
print - - -3168
print - (input())
tmp14
Temp7 = (input() + Tmp5)
print input()
temp10 = Temp7
((-58063))
print TMP6
T2 = (input())
print tmp12
print input()
print (36011) #test comment
 #test comment
print input() + - -8481 + - TMP6
tmp14 = T0
- T0
input() + input() + input() + - (39869) + input()
- TMP15
print 61722 + - input()
t8 = (t4)
print -19225
(Temp9)
tmp12 = (- -63541)
Tmp5 = (- 42735)
print input()
print input()
-42808
print 3942
-415
Temp13
- (TMP1)
input()
Temp9 + input()
input()
T0
print 40289
print (-43451 + - 50478) #test comment
(25980)
print 1534
- - - 8727 + t4
print - input() + input()
(- 6980)
- tmp12
print ((- (TMP6)))
print (t8)
tmp3 = -14689
input()
print (-45373)
Temp9 = (- TMP6 + (TMP1))
(input())
Tmp5 = - (56497)
TMP15
print - - tmp12
-32342
TMP1
T2 = -9298 + tmp3
temp10 = - input()
input()
T0 = - tmp12
- (-51360 + T0 + Tmp5)
temp10 = Temp13
print 35874
print t4 + (((-36891)) + (input()))
(- Temp9) + input()
TMP6 = - Temp7 + -31770
Temp7
t8 = (Temp13)
 #test comment
input()
print -55281
print 40983
print (input())
temp10
print tmp14
print - - input() + t4
print (T0)
(943 + 15621)
print (-38619 + -37154)
- Temp13
print TMP1
Tmp5 = 14966
input()
print TMP15
print 12823
T0 = (TMP6)
print temp10 + (((Temp11) + Temp13))
tmp12 = (- input())
print TMP15
Temp11 = Temp13
TMP1 = -64057
TMP6 = ((input())) + (-23076)
print input()
print tmp14 + input()
print ((input()))
44575
print - input()
input()
 #test comment
print tmp3
print T2
print (-7361)
input()
TMP6 = (input())
TMP6 = input() + t4
temp10 = (298)
print (- t4) + Temp9
(tmp14)
print tmp14
t8
print input()
-28995
print (- (- - (41482) + T2))
print input()
print tmp3
print t4
print 8998
print Temp9
print -6340
Temp7 = Temp13 #test comment
TMP6 = (- input())
T2 = (25431 + ((input()) + 27926) + - -34449) #test comment
print - Temp7
- temp10
print - Temp13 + input()
print -58315
tmp12
- temp10
print - (Temp11 + -4827)
Temp11 = - 34511
tmp3
print input()
- input() #test comment
print input() + 52769
print 30607
T0
print 44186
Temp13 = 12193 + (input())
58823
input() + (input()) + T2
- input()
(t4)
print TMP1
print (TMP6)
tmp14 = (input())
T2 = 61468
print Tmp5
((Temp11))
t8 = - T0
Temp13 = (input())
print (- - -28186)
Tmp16 = -64530
t4 = -27973 + Temp7
print - 60964 + - - 9647 + tmp3
TMP6 = (- (tmp3) + input())
print - input() + Tmp5
input()
Temp7 = - 53749
print 49149
46594 + - (input() + input() + Temp13)
- - input()
t4 = Tmp16
tmp12 = t8
- t4 + (Temp13)
21903
TMP15
print input()
tmp3 = TMP15
print temp10
tmp14 = input() + - 18741
(-48199)
Tmp16 = Temp13
print (- (tmp12) + input())
print input() + input()
T2
T0 = input()
t8 = 28236
input()
print input()
print 27862 + input()
print - (59645)
TMP1 = (input())
Temp9 = input()
print T0 + input()
print input()
tmp14 = tmp14
(64118)
T17 = tmp14
input() + (- -2998)
t8 = input()
print (Temp7)
-59474
Temp9 = - input() #test comment
 #test comment
(-10030)
print - -12837
TMP6 = - - (input()) + -9756
TMP6 = 6470 + (input()) + - (- 55776)
print (-16960)
-43335
print 10384
print - -11330
T0 = (-46496 + -16561)
print tmp3 + - input()
- - t4 + Temp9 + input() + (input())
TMP1
print (- - - (input()) + ((- input() + - -5811 + t8)) + 10507 + (- input() + Tmp5))
print TMP15
print (- -6481)
print 23523
Temp7 = Temp9
T17 = 58657
tmp12 = TMP6 + -4676 + input()
tmp12 = Tmp16
64404
Temp7 = - TMP1
tmp12 = - -53682 + (13189) + ((Temp7))
input()
T2 = TMP1
print Tmp5
TMP18 = -27093
t4 = (- - (TMP6))
input()
print ((Tmp16)) + input() + -43811 + t4 + - - ((45822)) + - T17 + 14755
15798
t8 = - input()
tmp14 = 44333
print - - - 13190 + (input()) + input() + t4
print TMP18
Tmp5 = - input() + tmp14
print (- Temp11 + input() + input())
44023
TMP1 = - (TMP1) + - -48708 + - input() + Temp11 + (input() + Tmp5)
print input()
- 22660
- - - input()
print 49300
-23869
print (input())
TMP1 = (input())
T2 = Tmp5
Temp9 = input()
temp10 = TMP1
print (64067)
- -42098 + (- Tmp16)
print - (- t8)
print -38386 + (- (input()))
tmp3 = T17
-40277
tmp3
print -7463
T17
- - T2 + - t8 #test comment
print - Temp13
TMP18 = - Tmp16
print input()
 #test comment
t4 = -11870
print input()
input()
print (34000) + (input()) + T2
print 29891
TMP18
(input())
T17 #test comment
print t8
TMP15 = ((- - Tmp16 + input())) + T2
tmp14 = 22706
print - T17
TMP18 = input()
print - - - (13204) + tmp14 + TMP1
print TMP1
print -6312 + 47656
print (input() + ((input()) + input()) + input()) #test comment
 #test comment
 
t4 = input()
tmp14 = - tmp14
Temp11 = ((- input())) + - - input()
-11692
Temp11 = 19976
print input()
TMP15 = (TMP15 + (tmp3))
print - input()
print input()
print - 32708
TMP6 = - input()
print input()
Tmp5 = input()
- TMP18
Tmp5 = -64397
temp10
print (Temp9)
Temp7 = ((Temp9)) + (((input() + TMP18 + 5482)))
T17 = ((- input() + - t4 + - (input()) + -57352 + Temp11)) + -61222
T17 = -45053
t4 = (input())
TMP6 = - tmp3 + (((-34764 + - - input())) + input())
 #test comment
print - 11997 + Temp11 + ((input()))
Temp9 = -7491 + - - - - input() + - - tmp14 + tmp12
t19 = - (-50829) + T0
print (input() + 43545) + TMP18
Temp13 = -53960
print input()
print -132
input()
t19 = input()
(- t19)
print -43172
temp10 = - TMP15 + Temp11
print 52103
58244
input()
print - - input() + input()
t4 = input()
print - Temp7 + -31128 + 47506
-56051
tmp20 = (8821)
Temp13
 #test comment
T17 = - -39093
print (input() + input())
print - t8 + ((input() + (input() + input())) + - (TMP15) + (Temp7 + - -12228) + input())
tmp12 = (23517)
tmp14
print tmp14
print (- (- input()))
print - - -14622
(input())
print input()
print - 50533
tmp12 = input() + T17
T17 = ((TMP6) + (-34569) + T2)
(46695)
- - - TMP6 + input()
TMP1 = (42250)
print 36867
T17
- tmp14 + (Temp13)
Temp9 = - - (Temp13)
-4849 + tmp14
Temp9 = - - input() + (- TMP1 + input() + (input()))
TMP1 = - T17
tmp12
print input()
print input() + 31977 + -3133 + input() + input()
temp21 = TMP15
print (11827)
- ((- - input()))
Tmp5 = input()
(TMP18 + input())
Temp13
temp10 = (temp21) + - input()
print (-44785)
- - input()
tmp3
T2 = ((-10710))
print - input()
Temp7 = TMP15
Temp13 = input()
TMP6 = temp10
T2
-29822 + 7720
Temp7 = 17197
TMP6 = -19873
print - ((- T0 + - input())) + - -48041 + TMP1
Tmp16 = (-47707 + input() + 59935 + (- t8) + - input())
print tmp14
print - 63748 + input()
- input()
- 40228
print input()
(TMP15)
print TMP6
tmp3 = Temp11 + tmp14 + TMP15 + (input())
print - ((TMP1 + - tmp3 + - temp10 + input()))
Temp13 = - - (T17) + Temp13 + temp10 + input() + - - ((16448))
t4 = (input()) + -798 + tmp12 + tmp20 + 39642 + input()
-62034
tmp12 = (input())
print -60465
print Tmp16
print TMP1
t8 = input()
-39118
input()
tmp14 = - (TMP15)
print 761
print 5980
print - -30254
- - input() + (-24973) + (- input()) #test comment
Temp9 = (- (T2))
print T17
TMP6 = input()
26526
print (- - - 43521)
(input())
temp21 = -7060
print input()
- (input() + - input()) + - input() + Temp13
print T17
print (t4) + - (input()) + input() + tmp3
Temp11 = (- -31411)
print 27305
10543
input()
 #test comment
print - - - - 5102
print input()
-51527
print (- input()) + tmp14 + (- (tmp3) + temp10) + -58642 + 43580
tmp14
(input() + 30989 + temp21)
Tmp16 = ((58353))
-630
print 11839
print (Temp11)
Tmp5 = (-47603) + input() + 44352 + input() + input() + -38504
t8 = input() + input()
print input()
print (Temp9)
print input()
- 21633
print - tmp14
- - - -1304
print - tmp20
Tmp5 = input() + -59644
print input()
print 58728
T2
tmp14 = - -47384
print TMP18 + 59699 + ((-36907) + -33978) + input() + temp21
-65297
input()
TMP15
print input()
T2 = input()
Temp7 = (input())
t8 + -21629
print input()
t4 = - (input() + (input()) + -65402) + TMP15 + input() + (- (temp10)) + Temp13
print - (- input() + input()) + - T17
print (-28482)
TMP15 = TMP6
13693
 #test comment
- t4
input() + 3633
print 61556
- input()
print -51866
print input()
input()
print input()
input()
print 9441
print - T2
print T2
-17766
Temp11 = 45695
tmp20 = - - input() + tmp20
print 146
print - 16381 + - input()
t4 = -321
-47629
T17 = 1384
TMP6 = (- -19949 + (- Tmp16 + input()) + (53070)) + input() + TMP6
input()
Tmp16 = (43628) + -40831
print 45228 + (31820 + (- (8155)))
input()
print -31414
- input()
print -21628
print 55087
T0 = (tmp3)
print (Temp7 + - TMP15 + 45366) + input() + input()
print input() + - temp10 + Temp7 + TMP6
tmp3 = tmp3
print tmp20 + (Tmp16)
Temp13 = -16441 + 39602
(-26196)
Tmp16 = input()
TMP1 = - Tmp5
print input()
Temp9 = -34810
print ((input()))
print T17
(57104)
tmp14
print (input())
input()
temp10 = tmp3
print tmp12
((input()) + 54443)
print input() + input()
t19
t8 = input()
tmp12 = input() + - -53227 + - input() + tmp20
print - input() + ((((- (T2 + t4))))) + input() + temp21
Temp9 = -36233
print tmp20
Tmp16 = (((- (((-43455)))))) + - - 25846
-61971
T0 = - - input() + 33885 #test comment
(53305)
tmp3 = Temp7
8769
(t8)
print - T2 + - - -13232 + - input() + input() + - 31866 + 33759 + input()
T17 = TMP6
4937
temp21 = (- Tmp16) + - -57519
Tmp5 = (6279)
-24488
tmp3
(-19329)
((TMP18))
print - (- - tmp12 + (input()))
print 58680
-7198
print - input()
print - 31360 + -16884 + - 36499
print Tmp16
tmp20 = - - temp10 + - TMP1 + input() + ((-10068))
print input()
tmp12 = input()
- input()
print input()
t19 = 32749
- (36634)
Temp11 = -42185
print input()
TMP1 = input()
TMP15
temp10 = tmp12
Temp7 + t4
Temp11 = Temp11
temp10 = -28902
print - - tmp3
print t19
tmp14 = input()
(23621)
t8 = (tmp12 + (input()) + (TMP6) + input() + input()) + tmp3 + T17 + 43566 + 36066
print -35030
print - -61462
print - ((input()))
print (-28407)
print - t4
input()
T0 = (((-4256)))
tmp14 = (T2)
print input() + tmp20
23480
- - - input() + -23968 + (TMP18) + input() + input() + - input()
TMP15 = 9114 + input()
input()
print - TMP6
print (9145)
input()
print -43947
Temp11
temp21 = input()
Tmp5 = 57712 + - - 44077
(63651)
 #test comment
print (- (-36257 + -1653))
-36996
Temp7 = -56930 + - 43122 + -14532
T22 = - (input())
print t19
T17 = input() + Temp9
TMP15 = ((- tmp20))
print 10421
(- Temp7) + t8
TMP18 = - 23906
25123
print (Temp9 + (7890))
Temp9
T17 = T2
- - input() + ((input() + Tmp5)) + input()
- - Temp13
print ((input()) + (input()))
print (- input())
Temp9 = T2
(18329 + input())
print - -57521
TEMP23 = temp10
print TMP15
tmp3 + 57521
TMP18 = - Temp13
print - (input())
tmp12 = input()
((T17)) + (49798)
print - input()
print Tmp5
print input() + 34564
print - - - 34675 + - - - T0 + Temp13 + input() + (21343) + input() + -51373
Tmp16 = TMP1
print input() + tmp20
print - TMP6
Tmp5 + input() + - input()
TMP1 = - temp10
t24 = - Temp9
tmp25 = input() + T17
Tmp16 = Temp11
T22
print Tmp5 + 57926
print -40256
T17 = (-33739)
print input()
print (4337)
tmp25 = - 16420
TMP15 = T17
print input()
Tmp5 = - TMP18
print input()
t4 = 53128
print 58837
print - (tmp25)
print -34335
print Temp7
print (- input())
- - - 10135 + 12717 + -2561 + Temp7
T0
 #test comment
Temp7
print (- - input())
t8 + - (- 48791) + - input()
60273
input()
input()
print - (((input())))
input()
t4 = - input()
- input()
print (56101)
tmp20 = 16307
15251
T17 = Temp13 + (input() + - input())
print (-50087 + input() + input())
print tmp12
print (10619)
print input()
- input()
input()
TMP6
-3697
TMP18 = ((input())) + 37197 + input()
print tmp14
print (-56344)
tmp12
Tmp16 = (- input())
print -34962
print -8021
print input()
Temp7
-14467
print (input())
print input()
input() + (- (input() + input()))
print 52135
print T22
print - input()
print (tmp3) + -40877
print input()
- - Temp11 + input()
TMP15 = (6785 + - -39086) + -57022
t4 = 22356
T22 = Temp7
print ((((t8 + 994))))
((-60391))
print TMP1
 #test comment
t4 = T22 + 1658
print input()
Temp13 = T22
tmp3 = input()
(Temp9)
temp21 = tmp20
print - 38120
input()
print (input() + (input()) + (Temp13) + (- -55111))
print 45642
TMP18 = - - Tmp5 + - (- T2) + (input()) + input() + - temp10
print 51324
print -21200
print tmp3 + -52609
temp21 = input()
6213
input()
print (input())
temp10 = Temp9
(Temp11)
(-21993)
#print all vars to ensure they are used at least once

print T0
print TMP1
print T2
print tmp3
print t4
print Tmp5
print TMP6
print Temp7
print t8
print Temp9
print temp10
print Temp11
print tmp12
print Temp13
print tmp14
print TMP15
print Tmp16
print T17
print TMP18
print t19
print tmp20
print temp21
print T22
print TEMP23
print t24
print tmp25
