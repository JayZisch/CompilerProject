#randomly generated p0 AST

print (- (- input()))
Tmp0 = input()
Tmp0
-34394 + (input()) + Tmp0
t1 = ((input()))
print Tmp0 + 698
print - t1
Tmp0 = ((- 4563))
(- input() + input() + (- Tmp0) + - input())
temp2 = 23584
input()
t1 = - input() + ((input() + 43752))
input()
print Tmp0 + -53364 + ((11253))
tmp3 = - input()
(- (- Tmp0 + - t1 + input()) + t1)
- - -27840 + (-53482) + - - - tmp3 + tmp3
Tmp0
tmp3
tmp3 = - 6712 + (-28944)
(temp2)
print t1
temp4 = - input()
print input()
temp2 = input() + t1
(56660) + input() + (-55717)
t1 = Tmp0
temp5 = input()
print (temp5)
input()
print input()
input()
print - - - (- t1 + (input()) + 45516) + (- - temp4)
- ((Tmp0)) + input()
(-41790)
t1 = -14133
temp4 = 55693
(temp5 + -16153)
temp5 = input()
print -33325
tmp3 = Tmp0
((19497))
temp2 = 8050
temp4 = input()
print - input()
input()
print ((input() + - Tmp0 + - (input())))
print - 56000
(temp5)
t6 = - input()
print 34170
print (input())
temp2 = input()
input()
31621
(temp4 + input() + Tmp0)
temp4 = (input())
temp4 = - - - temp2
input()
Tmp0 = (input())
-1844
T7 = Tmp0
temp2 = temp2
input()
Tmp0 = input() + - 62359
temp5
t1 = 50458
(t1)
tmp3 = t6
- 2850 + - - -10857
print 29792 + temp4
-43637
((input())) + temp4
input()
temp4 = - -19016
input() + tmp3 + (- - input()) + - 20586
input()
print 64891
-40599
print 23539
- T7
print - - - - (11217) + input()
-51713
print t1
Tmp0 = 53435
print 64919 + temp2 + - (input())
temp4 = (t6)
tmp3 = - - (- Tmp0 + - 36346 + input() + - -2922 + Tmp0 + 56221)
tmp3 = -44837
- (tmp3 + (16096) + (16167))
input()
temp5 = (- - T7 + (- -57697))
print input()
print - temp5
-45039 + input() + input()
print temp4
t1 = input()
13778
T7 = - - - -56349 + (- temp2) + ((- - 8912 + input() + input() + temp2) + T7 + input() + -10520 + tmp3 + temp4)
print input()
print input()
T7 = t1
tmp3 = input()
t1 = input()
62495
(48616)
1529
t1 = Tmp0
temp2
print - (- - (Tmp0))
t1 = temp2
input() + input()
Tmp0 = ((- input()) + (((input()))))
print - input()
print - - - temp5 + input() + (8675)
print - - - t6 + input()
t6 = (1293)
temp4 + - 30535 + -49328 + (- - - 9497)
print tmp3
print (input())
tmp3 = Tmp0
print - (((tmp3)))
temp8 = input()
(22413) + t6
temp4 = input()
print tmp3 + (input())
print input()
- - temp2
print Tmp0
input() + t6
print - -23116
print temp4
tmp3 = - - - -26011 + 5417 + (- tmp3) + - Tmp0
t6 = T7
input() + -22707
print - (- t1 + (-33321))
temp5 = T7 + temp8
print 65108 + - - - - 61940 + - input()
print input() + Tmp0
- - 40160 + input()
temp8
input()
print 14072
print - temp4 + input() + (- input() + - - input()) + Tmp0
temp4 = t6
- (- (-18344 + input()) + (input()))
print (- input() + -59117)
print input()
(temp2) + input() + - temp8 + (T7)
25657
print - -32893 + - t1 + - t1
print - ((input()) + -29135) + input() + temp8 + input()
-13563
print input()
- Tmp0
input()
print - t6 + input() + input() + -55602 + - - (- (input()))
-34845 + 30298
temp8
- - tmp3
64022
print (tmp3)
temp8 = - temp5
print temp8
temp8 = temp2
input()
t1 = - -15452
print input()
temp2 = - t1 + T7
print temp2
temp4 = tmp3
print 58509
print -39766 + - temp5
print temp8
print -30407
t1 = (- input())
input()
t6 = tmp3
print - input()
- temp5 + input() + - - - (30) + input()
temp8 = -45120
temp2 = t1
(input())
T7 = (- temp4 + 30397)
t1
print (input())
Temp9 = - temp5
print tmp3
t1 = Tmp0 + (((- (temp8)))) + (-3237 + - input()) + - T7
(32663 + 19617)
print Temp9 + -48074 + 30365
t1 = - temp2 + input() + - t1
((temp5))
(input() + Tmp0)
Temp9 = t1
- - 46791
temp2 = ((- - (input())))
print - 64973
print input()
(- -50715)
Tmp10 = (- Tmp0)
print -63472
input()
Tmp11 = (-32658) + (- temp4)
(temp4)
print - 49817 + temp8
temp8 = - (- - - Tmp0) + Tmp11
t6
(32153)
print - input()
Tmp11 = input()
(- -10861) + t6
Temp9
print Tmp10
Tmp11 = input() + temp4 + Temp9
Temp9 = input()
t1
print - - 38748 + - Tmp10 + 25237 + ((input()))
(((input())))
print -56290
print input()
temp8 = T7
tmp3
temp8 = 24567
T7
print (- (input()))
print (T7)
t1 = - temp4
print Tmp0
T7 = t6
733
(-5686)
Tmp10
temp8 = input()
Tmp12 = - - -42539 + temp8
Tmp11 = - 21361 + temp8
Tmp11 = -13883
temp2 = Temp9
print -16950
Tmp0 = input() + - (temp5)
-21296
temp5 = - (temp8)
print input()
print ((- - ((-39736))) + input())
- - ((64787))
(tmp3)
print 16064
temp4
temp5 = Temp9
(((temp8)))
(- t1 + (input()))
print (((Tmp11)))
print temp5
(-15035)
- Tmp11 + input()
-41386
temp8 = -45618
input()
Tmp12 = -16069
print input()
print - Tmp0
-988 + input()
print input()
temp5 = (input())
print (Tmp12 + (input()))
Tmp10 = temp4
-2652
T7 = - (- (Temp9))
print - -23237
print - input() + input()
print - Tmp11 + (- - (- Tmp12) + - - Tmp11 + (-25414) + - Tmp0 + 47282 + -19027 + (temp2)) + tmp3
input()
tmp3 = - - (- - Tmp0 + (- - input() + -49189)) + input() + - input()
- Tmp12
Temp9 = (input() + - (4977 + temp8) + (- - - (temp8)) + Tmp0)
print input()
print (input())
input()
T7 = temp5
print -48987
print -7433
print ((input()))
- -21231
input()
print input() + (input())
print (input()) + -61075
input()
print input()
Tmp12 = (temp2)
temp8 = t6
print 19186
input()
Tmp11 = - 51771
(input())
Tmp12 = temp2
-65451
Tmp11 = input()
temp8 = (input()) + -6427 + 44910 + (input())
47363
Tmp10
- input()
t6 = input()
print -5141 + (temp4)
Tmp12 = - ((-20700))
print (Tmp11)
print input()
- -3754
tmp3 = input()
print -56652
print (- (temp4 + 9435))
input() + 16985
Tmp12 = -53227
print -2874 + -17458
temp2
input()
print Temp9
print -57237
print - 24362 + Tmp10 + input() + t6
print t6
tmp3 = Tmp11
input()
t1 = input()
print - tmp3
(input()) + Temp9
Temp9 = - - -35899
Tmp0 = T7 + input() + ((12701))
- tmp3
Tmp0 = ((-63937))
temp5 = -16922
tmp3 = (-23563)
print input() + (-57172) + (- ((41490)))
input()
Tmp10 = ((input())) + - -2509 + t6
temp8 = - - Temp9
print Tmp10
input()
t6 = t6 + (input() + 20783 + -47727 + input())
13228
temp2 = input()
temp5 = (- (- 33786 + -12476))
7527
Tmp11 = input()
temp4
print - input() + 28305 + - Tmp12
Tmp0
print - temp2 + - input()
print -49174 + input()
input()
print - input() + input() + input()
temp5 = ((Tmp10))
-30117
58598
print - temp5 + (- t6) + - 6140 + input()
-31362
print input()
print -42691
t6
t1 = (- -47511)
Tmp0 = input() + -26822
print temp4
Tmp11 = 59103
print (Tmp0)
Tmp10 = - (-20698)
Temp9 = 4889
-14327
Tmp11 = Tmp11 + input() + (32644)
Tmp10
temp2 = ((2706) + input())
temp8 = input() + -22497
T7 = input()
-30177 + (input())
Temp9 = tmp3
52516
temp8 = 2367
print - T7 + tmp3
Temp9
(input() + - input() + 17173 + input()) + -59352
print input()
Tmp0 = (((Tmp0) + t6 + Tmp10))
32238
Tmp0 = t6
print - temp5
(input() + input())
-18942
Tmp11 = t1
print Temp9
18443
print 38518
print - temp5 + input()
temp2 = -4901 + T7 + (t1)
temp8
print input()
print (-38076)
print 52223
18156
-3867
Temp9 = temp2 + temp4 + (14112) + - 342 + input()
input()
- ((Tmp0))
Tmp0 = temp4
(input())
temp8 = (- Tmp0 + (temp5))
print ((temp4)) + input()
print (- 24121)
Tmp11 = input()
temp4 = - (input()) + - - input()
T7 = 29937
Tmp12 = temp8 + t6 + tmp3 + temp4
print (((-35559 + temp8))) + 52789 + temp2 + temp5 + - (t1) + input()
print -49902
temp5 = - (temp2 + - - input() + -62839 + input())
Tmp10 = input()
print Temp9 + - input() + (input()) + -37863
t1
print Tmp0
print input()
((input()))
t6
T7 = input()
print t6
Tmp11 + 42437
temp8 = input()
Tmp10 = -38563
print (- 18370) + (44379) + - (Tmp0 + -63437) + input() + input()
print (((-55405)))
temp2 = -65154
- - input()
input()
print Temp9
print - -64191
Temp9 = -20711
print input()
print - (-42541)
print ((input()))
t1 = input()
Tmp10
(input())
t1 = (- 35062) + - - input() + - - temp2
Temp9 = -51611
input()
TEMP13 = 15456 + 62022
print input() + 18426
temp4 = 43230
Temp9
print temp2
print 47192
t1
Tmp10 = -58521 + (Tmp11)
print input()
print - input() + input() + Tmp12
t1 = -4657
-43186
Tmp10 = input() + TEMP13
Tmp12 = - input()
Tmp10
T7 = - - -27609 + 24303
29542
print (-26319)
input() + input()
TEMP13 + -47735
Temp9 = - T7
(-48848)
print - (Tmp10)
temp5 = (- temp4)
temp8
Tmp0 = 50459
((temp8))
(input())
print (input())
28892 + tmp3 + -19390 + temp8 + - 1732
print (- - - Tmp12 + (input()))
- - 41788
print TEMP13
print temp5
temp5
TEMP13 = - - - T7
t6
temp4
print input()
- 16665 + 4080
T7 = input() + -31989
TEMP13
input()
Temp9 = 52816
Tmp12 = (- input() + -28926) + (- (32610 + 6500))
Temp9 = temp5
Tmp0
temp4 = Temp9
input()
print - input()
temp4 = input()
temp5 = input()
print 6379
temp8 = - input()
print temp2
temp8 = - (- (input() + Tmp12 + input()))
21107
input()
print - temp8 + 51951
print -62137
print input()
temp2 = - Temp9 + temp2
print Temp9
temp5 = input()
print - 14865 + (input()) + input()
temp2 = - -43977
Temp9
Tmp11 = 25979
temp5 = temp2
temp8 = Tmp0
print input()
input()
print 40755 + input()
print -53387 + (- - input()) + -23919
tmp3 = (Tmp0)
- (- - Temp9) + 30750 + (- - (input()))
62221
Tmp10 = (tmp3 + t1)
Tmp11
t6 = Tmp0
Tmp12 = tmp3
temp2 = -34035
T7 = input()
Tmp0 = (Temp9) + - Tmp12 + input()
Temp9
print input()
print - 19696
temp8 = -4958
print 9961
Tmp10 + - input() + input() + 7304
(Temp9 + - -29759)
print temp8
temp8
t6 = (- input())
Tmp10 = input()
temp5 = ((12771))
(15517) + 51029 + input() + input()
tmp3 = - -20305
print t6
tmp3 = input()
Tmp0 = input()
print temp2
print -34539
print 31204 + Temp9
t6
Tmp10 = -39133
Temp14 = 26216
(- - TEMP13)
- - input() + - - input() + - - - temp8 + ((- input()) + input())
temp5 = 33052
print Tmp11
T7 = -6409
Temp14 = Temp14
temp5 + - - - - Tmp12 + (26414 + input()) + - 33815 + 57846 + input()
print input()
print Tmp12
- -33831 + -31116
input() + t6
Tmp11 = input()
print input() + (input())
- -64650
print Temp9
print temp8
print - - - 59095 + -31218 + ((51815)) + input()
print ((input()))
TEMP13 = -64149
T7 = input()
- -46955 + - temp4 + input()
TEMP13 = (Temp9)
-1525
Tmp12 = input()
print - -65233
print 12874
input()
33863
- 22295
input()
print ((64928 + (input()) + Tmp11))
print input() + - t1 + input()
print (temp2)
Temp14
(((49393 + Tmp10)))
Temp14 = temp2
Tmp0 = - 54939
Tmp11 = Tmp0
print input()
print -22536
Temp14 = 63743
t1 = input()
print T7 + (3928)
print temp4
t6 = -22927
print (t1 + - Temp9 + -34566 + input() + Temp14 + (input()) + (-29291) + input() + temp5 + temp5)
print temp8
print - - input() + (-3029 + T7 + - (-34786))
print -45492
temp5 = input()
temp5 = -13649 + ((t1))
tmp3 = (-41666)
print (temp4 + (- Temp14)) + (7171 + (- - (- input()) + 65372 + input() + (Temp9)))
Tmp11 = ((temp8))
print (- - temp8 + temp2)
print input()
Temp14
Tmp15 = input()
temp4 = ((input()))
print -57628
t16 = temp8
temp8 = - input()
31262
t1 = ((input()))
- (- input() + (51250) + 61316) + (- - (- input() + ((2753))))
t16 = Tmp12
print input()
Tmp15 = (- - (Tmp15)) + -12402 + input()
print 26637
51734
t16
- 9519
input()
(input() + -31199 + (-34629)) + input()
Tmp0
((- input() + (36225) + - - - 17940))
print 37391
Tmp0 = tmp3
input()
TEMP13 = - Tmp12
Tmp10 = input()
input()
Tmp0 = - ((64191) + (input()))
print (23576)
t16 = 24821
print input()
input()
t6 = -16546
Tmp15 = -18605
print - 46449 + input()
Tmp11 = -31351 + Tmp0
- input()
print - 11141
tmp3 = -63753
temp8 = 1667
t1 = input()
t6 = ((Tmp10))
print temp8
temp5 = (tmp3)
Tmp0 = (input())
- - input()
print - (-18885) + Temp14
print (- -13646) + (temp4)
temp2 = - input()
TEMP13 = input()
temp2
T7 = input()
TEMP13 = input()
Tmp15 = -61322
t1 = (input())
(t1)
- - tmp3 + -44128 + Temp9 + (57600)
print input()
tmp3 = temp4
input()
print input()
input()
print - input() + (input())
print input()
print input()
9540
Tmp15 = Tmp11
print temp5
temp8
- t1
t16 = tmp3
print -5805
temp4 = - Tmp12
- (- input())
Tmp12 + 43813
print input()
T7 = -16476 + t1 + 12943
print - temp8
- (- (- 8491 + input())) + (input() + - T7) + (- input() + (Tmp12))
print input()
print temp4 + Tmp10 + input() + input()
print -9060
TEMP17 = Tmp15
print Temp9
input() + T7
Tmp11 = - (Tmp11)
print input() + (input() + Tmp12)
print temp8
print T7 + (- - input())
t6 = -23922
print 19842
Tmp12 = - ((- input()) + input()) + - (input())
-50807
temp2
Temp14 = - t6
print input() + input() + input() + (input())
Tmp11 = Tmp10
temp2 = (input())
Temp14 = input()
Tmp10 = TEMP17
TEMP13 = temp2
T7 = - input() + temp2
Temp9 = 7145
print - (input())
- input()
(- - (26026) + t6)
print t1
Tmp12 = input()
print t6
print -30786
print Tmp0
- (-40316) + (65502)
temp2 = input() + 30931 + temp5
TEMP13
t1 = (input() + t1)
input()
Tmp0 = (- -37553)
print 63633 + t6 + - - (input())
temp2
temp4 = TEMP13
print input()
t6 = - - -22926
print TEMP13
input()
tmp3
-438
input()
TEMP17 = input()
print - input()
print - (input())
print Temp14 + input()
Temp9 = -18879
print (temp5)
t1 + input() + - - input()
Tmp15 = (TEMP13 + 8124)
- temp5 + input()
t1 = - input()
print Temp9
tmp3 + 17069 + temp8 + (- temp4 + input()) + ((-50836 + TEMP13 + TEMP13))
print input() + t16
t16 = input()
print Tmp0 + (input() + (- TEMP13 + - input() + - Tmp12))
Tmp12
print input()
Tmp12 = (input()) + input()
(input())
t6 = - input()
((- 9839) + -51042 + (TEMP17) + -22635)
Temp14 = temp5
t16 = Tmp10
temp8 = input()
TMP18 = - (- (- -38792)) + temp4
- 1505 + (temp4) + - -23036 + (((input()) + Temp9 + Tmp0)) + temp5 + Tmp15 + t1 + input() + (-23854 + (- (TEMP13)))
t6 = - TMP18
Tmp11 = - input()
temp8 = -51120 + input()
- TMP18
temp5 = input()
input()
print - - input()
tmp3
Temp9 = - temp4
31828
temp2 = input() + (((temp4) + input()))
t16 = - input()
print TEMP13
t6 = (input() + - - - input() + 22149)
print (input())
(input())
Tmp10
print input()
print (-62353)
print 33362 + ((TEMP13))
print t6
print TEMP13
print - 40173
- input()
input()
TEMP13 = -35086
-57121
temp5 = -26815
print - (T7)
print 24866
Tmp19 = (- -781) + t6
input()
-21747
print (input())
print input()
temp5 = ((- input())) + - -17628 + (58567) + - (24752 + T7 + - 36916 + - - (((- input() + Tmp15))) + input() + - - - input() + Tmp15 + input() + input())
(- Tmp19 + -19983 + 55449)
print Temp14
Tmp0 = 60104
print - input() + input() + 41465
((-53891)) + (-29752) + - 24015
- (Tmp10 + - (input() + ((input()) + -11634)))
print - TEMP17
Tmp0 = - - input() + (Tmp0)
TMP18 = input() + -6354
tmp3
Tmp15 = (input())
(TEMP17) + (- (- Tmp10) + Temp9 + input())
print 46015
print - - Tmp12 + - - input()
input() + -4379 + input()
print - input() + input()
Tmp10 = (t6 + TMP18)
temp4 = input()
Tmp0 = -32883
temp20 = TEMP17 + input()
t16 = t6
t16 = (- 5378)
-47756 + input()
print (-46210) + - tmp3
temp5 = temp4
input()
print Tmp19
print input()
TEMP17 = - (- Tmp0)
- - (t6)
Tmp0 = temp8
t16
print ((6358))
t6 = input() + input() + input()
Tmp12 = temp4
input()
print TEMP13
Tmp10 = - TEMP17 + -47541
input() + - ((input()))
print T7
Tmp15
print (8379) + - Tmp19 + - input() + tmp3 + temp8
- (input())
Tmp15 = (input() + - -55166 + -56602)
(- (input()))
tmp3 = -39078
print temp8
print (- (input()) + TEMP17)
input()
- input()
T21 = (-19195 + -17721 + Temp9)
print - (t6)
input()
- 4601
temp2 = input()
Tmp10 = TMP18
tmp3 = input() + input()
print - - input() + - Temp14 + input() + 18024 + 6170 + temp8 + 23637 + - temp2 + input() + - - - temp4 + Temp9
t6 = (temp20 + TEMP17)
T7 = ((- input() + input()) + input() + - 56380 + - - - - input() + - 46454 + - input() + T7)
input()
(input())
(input())
TMP18 = t6
print (Temp14)
print - temp20
print - (t16)
print input()
input() + - input()
print input() + T21
print tmp3
t6 = input() + TEMP13
print input()
print - ((temp20))
TEMP17 = input()
Tmp19 = t6
temp8 = input()
print t1 + Temp9
(-55977 + 32186)
print input()
print - -55451
- (TEMP17 + input())
- -63957 + -39211 + input() + input()
input()
temp5 = - TMP18
print input()
-16041 + -57586
-54168
tmp3 = input() + tmp3
temp2 = - - -28486
1857
Tmp0 = 17338
Temp14
print ((input()))
temp8 = input()
(temp5)
- input() + T21
TMP18 = t1
temp5
input()
Tmp12 = input()
Tmp0 = input() + (-42495) + - input() + input() + - input() + input() + input()
print - (- temp8) + ((- - 26265))
print input()
print - 64367
- input()
print -43650 + Temp9
print 32028
64205
Tmp19 = -17395
Tmp0 = 8058
Tmp0 = T7
temp4 = ((-52879))
(input())
((input()))
temp2
t1 = ((TEMP13))
-55114
print 25553
(- (-29635))
Tmp19 = input()
Tmp12 = input()
Tmp12 = -14004
57817
(((input())))
t16 = (- (- - 12938) + -29424) + - input() + - input() + -24651 + - 30609
print (input() + (TEMP17) + input())
- input()
print (- - - (input()) + -3093 + (- temp4))
input()
print -2055
TMP18 = t6
temp5
input()
print (temp20)
T21
temp2
- - 27590
60313
input() + input()
t6 = - Tmp19
(- ((- - TEMP13)) + (Tmp12 + -15550) + (-44063) + - t16 + (- -33936 + temp8) + 64024 + - (T7) + 5614)
Tmp0 = temp4
print Tmp15
print input()
tmp3
print input()
print input()
temp5 = tmp3
- - (((temp5) + temp4))
print -51773
print input()
t1 = temp4
print - 50384 + input()
print input()
t6 = -10362
print t16
- Tmp11
print - (25059)
print Temp14
Tmp12 = Temp14
print 55336
(TEMP17)
TEMP13 = (- input() + - Temp14 + ((- input())))
print (5514)
TEMP13 + input()
Tmp15 = temp4
input()
input()
(TMP18)
Temp9 = temp2
(temp5)
Tmp11 = 6627 + -64748 + - 26706
tmp3 = 44766
-41860
temp20 = (- input())
temp2 + -49379
t1 = - input()
- -16759
print 8529
print Temp9 + TMP18 + - t6 + input()
print input()
Tmp19 = t1
Tmp11 = - 18237 + (- TEMP13)
print -25710
print (- (input()))
temp20
(-63293 + input()) + input() + - - 21270
TMP18 = - - input()
T7 = Tmp19
temp5 = - - (57791) + - 50611 + input()
t16
TEMP13 = T21
- - - input() + (26501) + TEMP17
temp4 = - input()
Temp14 = ((input()))
print Temp14
Tmp19 = - -18346
temp4 = -35190
print Tmp12 + - - input() + - input()
print TEMP17
print (input())
input()
Temp22 = 56187
t16 = (- TEMP17)
(temp5)
t6 = 22133
TEMP17
((-16661))
#print all vars to ensure they are used at least once

print Tmp0
print t1
print temp2
print tmp3
print temp4
print temp5
print t6
print T7
print temp8
print Temp9
print Tmp10
print Tmp11
print Tmp12
print TEMP13
print Temp14
print Tmp15
print t16
print TEMP17
print TMP18
print Tmp19
print temp20
print T21
print Temp22