
tmp0 = input()
tmp1=input()
tmp2 = tmp1 +- tmp0
print tmp2
tmp3 = tmp2 +- tmp1
print tmp3
tmp4 = tmp3 +- tmp2
print tmp4
tmp5 = tmp4 +- tmp3
print tmp5
tmp6 = tmp5 +- tmp4
print tmp6
tmp7 = tmp6 +- tmp5
print tmp7
tmp8 = tmp7 +- tmp6
print tmp8
tmp9 = tmp8 +- tmp7
print tmp9
tmp10 = tmp9 +- tmp8
print tmp10
tmp11 = tmp10 +- tmp9
print tmp11
tmp12 = tmp11 +- tmp10
print tmp12
tmp13 = tmp12 +- tmp11
print tmp13
tmp14 = tmp13 +- tmp12
print tmp14
tmp15 = tmp14 +- tmp13
print tmp15
tmp16 = tmp15 +- tmp14
print tmp16
tmp17 = tmp16 +- tmp15
print tmp17
tmp18 = tmp17 +- tmp16
print tmp18
tmp19 = tmp18 +- tmp17
print tmp19
tmp20 = tmp19 +- tmp18
print tmp20
tmp21 = tmp20 +- tmp19
print tmp21
tmp22 = tmp21 +- tmp20
print tmp22
tmp23 = tmp22 +- tmp21
print tmp23
tmp24 = tmp23 +- tmp22
print tmp24
tmp25 = tmp24 +- tmp23
print tmp25
tmp26 = tmp25 +- tmp24
print tmp26
tmp27 = tmp26 +- tmp25
print tmp27
tmp28 = tmp27 +- tmp26
print tmp28
tmp29 = tmp28 +- tmp27
print tmp29
tmp30 = tmp29 +- tmp28
print tmp30
tmp31 = tmp30 +- tmp29
print tmp31
tmp32 = tmp31 +- tmp30
print tmp32
tmp33 = tmp32 +- tmp31
print tmp33
tmp34 = tmp33 +- tmp32
print tmp34
tmp35 = tmp34 +- tmp33
print tmp35
tmp36 = tmp35 +- tmp34
print tmp36
tmp37 = tmp36 +- tmp35
print tmp37
tmp38 = tmp37 +- tmp36
print tmp38
tmp39 = tmp38 +- tmp37
print tmp39
tmp40 = tmp39 +- tmp38
print tmp40
tmp41 = tmp40 +- tmp39
print tmp41
tmp42 = tmp41 +- tmp40
print tmp42
tmp43 = tmp42 +- tmp41
print tmp43
tmp44 = tmp43 +- tmp42
print tmp44
tmp45 = tmp44 +- tmp43
print tmp45
tmp46 = tmp45 +- tmp44
print tmp46
tmp47 = tmp46 +- tmp45
print tmp47
tmp48 = tmp47 +- tmp46
print tmp48
tmp49 = tmp48 +- tmp47
print tmp49
tmp50 = tmp49 +- tmp48
print tmp50
tmp51 = tmp50 +- tmp49
print tmp51
tmp52 = tmp51 +- tmp50
print tmp52
tmp53 = tmp52 +- tmp51
print tmp53
tmp54 = tmp53 +- tmp52
print tmp54
tmp55 = tmp54 +- tmp53
print tmp55
tmp56 = tmp55 +- tmp54
print tmp56
tmp57 = tmp56 +- tmp55
print tmp57
tmp58 = tmp57 +- tmp56
print tmp58
tmp59 = tmp58 +- tmp57
print tmp59
tmp60 = tmp59 +- tmp58
print tmp60
tmp61 = tmp60 +- tmp59
print tmp61
tmp62 = tmp61 +- tmp60
print tmp62
tmp63 = tmp62 +- tmp61
print tmp63
tmp64 = tmp63 +- tmp62
print tmp64
tmp65 = tmp64 +- tmp63
print tmp65
tmp66 = tmp65 +- tmp64
print tmp66
tmp67 = tmp66 +- tmp65
print tmp67
tmp68 = tmp67 +- tmp66
print tmp68
tmp69 = tmp68 +- tmp67
print tmp69
tmp70 = tmp69 +- tmp68
print tmp70
tmp71 = tmp70 +- tmp69
print tmp71
tmp72 = tmp71 +- tmp70
print tmp72
tmp73 = tmp72 +- tmp71
print tmp73
tmp74 = tmp73 +- tmp72
print tmp74
tmp75 = tmp74 +- tmp73
print tmp75
tmp76 = tmp75 +- tmp74
print tmp76
tmp77 = tmp76 +- tmp75
print tmp77
tmp78 = tmp77 +- tmp76
print tmp78
tmp79 = tmp78 +- tmp77
print tmp79
tmp80 = tmp79 +- tmp78
print tmp80
tmp81 = tmp80 +- tmp79
print tmp81
tmp82 = tmp81 +- tmp80
print tmp82
tmp83 = tmp82 +- tmp81
print tmp83
tmp84 = tmp83 +- tmp82
print tmp84
tmp85 = tmp84 +- tmp83
print tmp85
tmp86 = tmp85 +- tmp84
print tmp86
tmp87 = tmp86 +- tmp85
print tmp87
tmp88 = tmp87 +- tmp86
print tmp88
tmp89 = tmp88 +- tmp87
print tmp89
tmp90 = tmp89 +- tmp88
print tmp90
tmp91 = tmp90 +- tmp89
print tmp91
tmp92 = tmp91 +- tmp90
print tmp92
tmp93 = tmp92 +- tmp91
print tmp93
tmp94 = tmp93 +- tmp92
print tmp94
tmp95 = tmp94 +- tmp93
print tmp95
tmp96 = tmp95 +- tmp94
print tmp96
tmp97 = tmp96 +- tmp95
print tmp97
tmp98 = tmp97 +- tmp96
print tmp98
tmp99 = tmp98 +- tmp97
print tmp99
tmp100 = tmp99 +- tmp98
print tmp100
tmp101 = tmp100 +- tmp99
print tmp101
tmp102 = tmp101 +- tmp100
print tmp102
tmp103 = tmp102 +- tmp101
print tmp103
tmp104 = tmp103 +- tmp102
print tmp104
tmp105 = tmp104 +- tmp103
print tmp105
tmp106 = tmp105 +- tmp104
print tmp106
tmp107 = tmp106 +- tmp105
print tmp107
tmp108 = tmp107 +- tmp106
print tmp108
tmp109 = tmp108 +- tmp107
print tmp109
tmp110 = tmp109 +- tmp108
print tmp110
tmp111 = tmp110 +- tmp109
print tmp111
tmp112 = tmp111 +- tmp110
print tmp112
tmp113 = tmp112 +- tmp111
print tmp113
tmp114 = tmp113 +- tmp112
print tmp114
tmp115 = tmp114 +- tmp113
print tmp115
tmp116 = tmp115 +- tmp114
print tmp116
tmp117 = tmp116 +- tmp115
print tmp117
tmp118 = tmp117 +- tmp116
print tmp118
tmp119 = tmp118 +- tmp117
print tmp119
tmp120 = tmp119 +- tmp118
print tmp120
tmp121 = tmp120 +- tmp119
print tmp121
tmp122 = tmp121 +- tmp120
print tmp122
tmp123 = tmp122 +- tmp121
print tmp123
tmp124 = tmp123 +- tmp122
print tmp124
tmp125 = tmp124 +- tmp123
print tmp125
tmp126 = tmp125 +- tmp124
print tmp126
tmp127 = tmp126 +- tmp125
print tmp127
tmp128 = tmp127 +- tmp126
print tmp128
tmp129 = tmp128 +- tmp127
print tmp129
tmp130 = tmp129 +- tmp128
print tmp130
tmp131 = tmp130 +- tmp129
print tmp131
tmp132 = tmp131 +- tmp130
print tmp132
tmp133 = tmp132 +- tmp131
print tmp133
tmp134 = tmp133 +- tmp132
print tmp134
tmp135 = tmp134 +- tmp133
print tmp135
tmp136 = tmp135 +- tmp134
print tmp136
tmp137 = tmp136 +- tmp135
print tmp137
tmp138 = tmp137 +- tmp136
print tmp138
tmp139 = tmp138 +- tmp137
print tmp139
tmp140 = tmp139 +- tmp138
print tmp140
tmp141 = tmp140 +- tmp139
print tmp141
tmp142 = tmp141 +- tmp140
print tmp142
tmp143 = tmp142 +- tmp141
print tmp143
tmp144 = tmp143 +- tmp142
print tmp144
tmp145 = tmp144 +- tmp143
print tmp145
tmp146 = tmp145 +- tmp144
print tmp146
tmp147 = tmp146 +- tmp145
print tmp147
tmp148 = tmp147 +- tmp146
print tmp148
tmp149 = tmp148 +- tmp147
print tmp149
tmp150 = tmp149 +- tmp148
print tmp150
tmp151 = tmp150 +- tmp149
print tmp151
tmp152 = tmp151 +- tmp150
print tmp152
tmp153 = tmp152 +- tmp151
print tmp153
tmp154 = tmp153 +- tmp152
print tmp154
tmp155 = tmp154 +- tmp153
print tmp155
tmp156 = tmp155 +- tmp154
print tmp156
tmp157 = tmp156 +- tmp155
print tmp157
tmp158 = tmp157 +- tmp156
print tmp158
tmp159 = tmp158 +- tmp157
print tmp159
tmp160 = tmp159 +- tmp158
print tmp160
tmp161 = tmp160 +- tmp159
print tmp161
tmp162 = tmp161 +- tmp160
print tmp162
tmp163 = tmp162 +- tmp161
print tmp163
tmp164 = tmp163 +- tmp162
print tmp164
tmp165 = tmp164 +- tmp163
print tmp165
tmp166 = tmp165 +- tmp164
print tmp166
tmp167 = tmp166 +- tmp165
print tmp167
tmp168 = tmp167 +- tmp166
print tmp168
tmp169 = tmp168 +- tmp167
print tmp169
tmp170 = tmp169 +- tmp168
print tmp170
tmp171 = tmp170 +- tmp169
print tmp171
tmp172 = tmp171 +- tmp170
print tmp172
tmp173 = tmp172 +- tmp171
print tmp173
tmp174 = tmp173 +- tmp172
print tmp174
tmp175 = tmp174 +- tmp173
print tmp175
tmp176 = tmp175 +- tmp174
print tmp176
tmp177 = tmp176 +- tmp175
print tmp177
tmp178 = tmp177 +- tmp176
print tmp178
tmp179 = tmp178 +- tmp177
print tmp179
tmp180 = tmp179 +- tmp178
print tmp180
tmp181 = tmp180 +- tmp179
print tmp181
tmp182 = tmp181 +- tmp180
print tmp182
tmp183 = tmp182 +- tmp181
print tmp183
tmp184 = tmp183 +- tmp182
print tmp184
tmp185 = tmp184 +- tmp183
print tmp185
tmp186 = tmp185 +- tmp184
print tmp186
tmp187 = tmp186 +- tmp185
print tmp187
tmp188 = tmp187 +- tmp186
print tmp188
tmp189 = tmp188 +- tmp187
print tmp189
tmp190 = tmp189 +- tmp188
print tmp190
tmp191 = tmp190 +- tmp189
print tmp191
tmp192 = tmp191 +- tmp190
print tmp192
tmp193 = tmp192 +- tmp191
print tmp193
tmp194 = tmp193 +- tmp192
print tmp194
tmp195 = tmp194 +- tmp193
print tmp195
tmp196 = tmp195 +- tmp194
print tmp196
tmp197 = tmp196 +- tmp195
print tmp197
tmp198 = tmp197 +- tmp196
print tmp198
tmp199 = tmp198 +- tmp197
print tmp199
tmp200 = tmp199 +- tmp198
print tmp200
tmp201 = tmp200 +- tmp199
print tmp201
tmp202 = tmp201 +- tmp200
print tmp202
tmp203 = tmp202 +- tmp201
print tmp203
tmp204 = tmp203 +- tmp202
print tmp204
tmp205 = tmp204 +- tmp203
print tmp205
tmp206 = tmp205 +- tmp204
print tmp206
tmp207 = tmp206 +- tmp205
print tmp207
tmp208 = tmp207 +- tmp206
print tmp208
tmp209 = tmp208 +- tmp207
print tmp209
tmp210 = tmp209 +- tmp208
print tmp210
tmp211 = tmp210 +- tmp209
print tmp211
tmp212 = tmp211 +- tmp210
print tmp212
tmp213 = tmp212 +- tmp211
print tmp213
tmp214 = tmp213 +- tmp212
print tmp214
tmp215 = tmp214 +- tmp213
print tmp215
tmp216 = tmp215 +- tmp214
print tmp216
tmp217 = tmp216 +- tmp215
print tmp217
tmp218 = tmp217 +- tmp216
print tmp218
tmp219 = tmp218 +- tmp217
print tmp219
tmp220 = tmp219 +- tmp218
print tmp220
tmp221 = tmp220 +- tmp219
print tmp221
tmp222 = tmp221 +- tmp220
print tmp222
tmp223 = tmp222 +- tmp221
print tmp223
tmp224 = tmp223 +- tmp222
print tmp224
tmp225 = tmp224 +- tmp223
print tmp225
tmp226 = tmp225 +- tmp224
print tmp226
tmp227 = tmp226 +- tmp225
print tmp227
tmp228 = tmp227 +- tmp226
print tmp228
tmp229 = tmp228 +- tmp227
print tmp229
tmp230 = tmp229 +- tmp228
print tmp230
tmp231 = tmp230 +- tmp229
print tmp231
tmp232 = tmp231 +- tmp230
print tmp232
tmp233 = tmp232 +- tmp231
print tmp233
tmp234 = tmp233 +- tmp232
print tmp234
tmp235 = tmp234 +- tmp233
print tmp235
tmp236 = tmp235 +- tmp234
print tmp236
tmp237 = tmp236 +- tmp235
print tmp237
tmp238 = tmp237 +- tmp236
print tmp238
tmp239 = tmp238 +- tmp237
print tmp239
tmp240 = tmp239 +- tmp238
print tmp240
tmp241 = tmp240 +- tmp239
print tmp241
tmp242 = tmp241 +- tmp240
print tmp242
tmp243 = tmp242 +- tmp241
print tmp243
tmp244 = tmp243 +- tmp242
print tmp244
tmp245 = tmp244 +- tmp243
print tmp245
tmp246 = tmp245 +- tmp244
print tmp246
tmp247 = tmp246 +- tmp245
print tmp247
tmp248 = tmp247 +- tmp246
print tmp248
tmp249 = tmp248 +- tmp247
print tmp249
tmp250 = tmp249 +- tmp248
print tmp250
tmp251 = tmp250 +- tmp249
print tmp251
tmp252 = tmp251 +- tmp250
print tmp252
tmp253 = tmp252 +- tmp251
print tmp253
tmp254 = tmp253 +- tmp252
print tmp254
tmp255 = tmp254 +- tmp253
print tmp255
tmp256 = tmp255 +- tmp254
print tmp256
tmp257 = tmp256 +- tmp255
print tmp257
tmp258 = tmp257 +- tmp256
print tmp258
tmp259 = tmp258 +- tmp257
print tmp259
tmp260 = tmp259 +- tmp258
print tmp260
tmp261 = tmp260 +- tmp259
print tmp261
tmp262 = tmp261 +- tmp260
print tmp262
tmp263 = tmp262 +- tmp261
print tmp263
tmp264 = tmp263 +- tmp262
print tmp264
tmp265 = tmp264 +- tmp263
print tmp265
tmp266 = tmp265 +- tmp264
print tmp266
tmp267 = tmp266 +- tmp265
print tmp267
tmp268 = tmp267 +- tmp266
print tmp268
tmp269 = tmp268 +- tmp267
print tmp269
tmp270 = tmp269 +- tmp268
print tmp270
tmp271 = tmp270 +- tmp269
print tmp271
tmp272 = tmp271 +- tmp270
print tmp272
tmp273 = tmp272 +- tmp271
print tmp273
tmp274 = tmp273 +- tmp272
print tmp274
tmp275 = tmp274 +- tmp273
print tmp275
tmp276 = tmp275 +- tmp274
print tmp276
tmp277 = tmp276 +- tmp275
print tmp277
tmp278 = tmp277 +- tmp276
print tmp278
tmp279 = tmp278 +- tmp277
print tmp279
tmp280 = tmp279 +- tmp278
print tmp280
tmp281 = tmp280 +- tmp279
print tmp281
tmp282 = tmp281 +- tmp280
print tmp282
tmp283 = tmp282 +- tmp281
print tmp283
tmp284 = tmp283 +- tmp282
print tmp284
tmp285 = tmp284 +- tmp283
print tmp285
tmp286 = tmp285 +- tmp284
print tmp286
tmp287 = tmp286 +- tmp285
print tmp287
tmp288 = tmp287 +- tmp286
print tmp288
tmp289 = tmp288 +- tmp287
print tmp289
tmp290 = tmp289 +- tmp288
print tmp290
tmp291 = tmp290 +- tmp289
print tmp291
tmp292 = tmp291 +- tmp290
print tmp292
tmp293 = tmp292 +- tmp291
print tmp293
tmp294 = tmp293 +- tmp292
print tmp294
tmp295 = tmp294 +- tmp293
print tmp295
tmp296 = tmp295 +- tmp294
print tmp296
tmp297 = tmp296 +- tmp295
print tmp297
tmp298 = tmp297 +- tmp296
print tmp298
tmp299 = tmp298 +- tmp297
print tmp299
tmp300 = tmp299 +- tmp298
print tmp300
tmp301 = tmp300 +- tmp299
print tmp301
tmp302 = tmp301 +- tmp300
print tmp302
tmp303 = tmp302 +- tmp301
print tmp303
tmp304 = tmp303 +- tmp302
print tmp304
tmp305 = tmp304 +- tmp303
print tmp305
tmp306 = tmp305 +- tmp304
print tmp306
tmp307 = tmp306 +- tmp305
print tmp307
tmp308 = tmp307 +- tmp306
print tmp308
tmp309 = tmp308 +- tmp307
print tmp309
tmp310 = tmp309 +- tmp308
print tmp310
tmp311 = tmp310 +- tmp309
print tmp311
tmp312 = tmp311 +- tmp310
print tmp312
tmp313 = tmp312 +- tmp311
print tmp313
tmp314 = tmp313 +- tmp312
print tmp314
tmp315 = tmp314 +- tmp313
print tmp315
tmp316 = tmp315 +- tmp314
print tmp316
tmp317 = tmp316 +- tmp315
print tmp317
tmp318 = tmp317 +- tmp316
print tmp318
tmp319 = tmp318 +- tmp317
print tmp319
tmp320 = tmp319 +- tmp318
print tmp320
tmp321 = tmp320 +- tmp319
print tmp321
tmp322 = tmp321 +- tmp320
print tmp322
tmp323 = tmp322 +- tmp321
print tmp323
tmp324 = tmp323 +- tmp322
print tmp324
tmp325 = tmp324 +- tmp323
print tmp325
tmp326 = tmp325 +- tmp324
print tmp326
tmp327 = tmp326 +- tmp325
print tmp327
tmp328 = tmp327 +- tmp326
print tmp328
tmp329 = tmp328 +- tmp327
print tmp329
tmp330 = tmp329 +- tmp328
print tmp330
tmp331 = tmp330 +- tmp329
print tmp331
tmp332 = tmp331 +- tmp330
print tmp332
tmp333 = tmp332 +- tmp331
print tmp333
tmp334 = tmp333 +- tmp332
print tmp334
tmp335 = tmp334 +- tmp333
print tmp335
tmp336 = tmp335 +- tmp334
print tmp336
tmp337 = tmp336 +- tmp335
print tmp337
tmp338 = tmp337 +- tmp336
print tmp338
tmp339 = tmp338 +- tmp337
print tmp339
tmp340 = tmp339 +- tmp338
print tmp340
tmp341 = tmp340 +- tmp339
print tmp341
tmp342 = tmp341 +- tmp340
print tmp342
tmp343 = tmp342 +- tmp341
print tmp343
tmp344 = tmp343 +- tmp342
print tmp344
tmp345 = tmp344 +- tmp343
print tmp345
tmp346 = tmp345 +- tmp344
print tmp346
tmp347 = tmp346 +- tmp345
print tmp347
tmp348 = tmp347 +- tmp346
print tmp348
tmp349 = tmp348 +- tmp347
print tmp349
tmp350 = tmp349 +- tmp348
print tmp350
tmp351 = tmp350 +- tmp349
print tmp351
tmp352 = tmp351 +- tmp350
print tmp352
tmp353 = tmp352 +- tmp351
print tmp353
tmp354 = tmp353 +- tmp352
print tmp354
tmp355 = tmp354 +- tmp353
print tmp355
tmp356 = tmp355 +- tmp354
print tmp356
tmp357 = tmp356 +- tmp355
print tmp357
tmp358 = tmp357 +- tmp356
print tmp358
tmp359 = tmp358 +- tmp357
print tmp359
tmp360 = tmp359 +- tmp358
print tmp360
tmp361 = tmp360 +- tmp359
print tmp361
tmp362 = tmp361 +- tmp360
print tmp362
tmp363 = tmp362 +- tmp361
print tmp363
tmp364 = tmp363 +- tmp362
print tmp364
tmp365 = tmp364 +- tmp363
print tmp365
tmp366 = tmp365 +- tmp364
print tmp366
tmp367 = tmp366 +- tmp365
print tmp367
tmp368 = tmp367 +- tmp366
print tmp368
tmp369 = tmp368 +- tmp367
print tmp369
tmp370 = tmp369 +- tmp368
print tmp370
tmp371 = tmp370 +- tmp369
print tmp371
tmp372 = tmp371 +- tmp370
print tmp372
tmp373 = tmp372 +- tmp371
print tmp373
tmp374 = tmp373 +- tmp372
print tmp374
tmp375 = tmp374 +- tmp373
print tmp375
tmp376 = tmp375 +- tmp374
print tmp376
tmp377 = tmp376 +- tmp375
print tmp377
tmp378 = tmp377 +- tmp376
print tmp378
tmp379 = tmp378 +- tmp377
print tmp379
tmp380 = tmp379 +- tmp378
print tmp380
tmp381 = tmp380 +- tmp379
print tmp381
tmp382 = tmp381 +- tmp380
print tmp382
tmp383 = tmp382 +- tmp381
print tmp383
tmp384 = tmp383 +- tmp382
print tmp384
tmp385 = tmp384 +- tmp383
print tmp385
tmp386 = tmp385 +- tmp384
print tmp386
tmp387 = tmp386 +- tmp385
print tmp387
tmp388 = tmp387 +- tmp386
print tmp388
tmp389 = tmp388 +- tmp387
print tmp389
tmp390 = tmp389 +- tmp388
print tmp390
tmp391 = tmp390 +- tmp389
print tmp391
tmp392 = tmp391 +- tmp390
print tmp392
tmp393 = tmp392 +- tmp391
print tmp393
tmp394 = tmp393 +- tmp392
print tmp394
tmp395 = tmp394 +- tmp393
print tmp395
tmp396 = tmp395 +- tmp394
print tmp396
tmp397 = tmp396 +- tmp395
print tmp397
tmp398 = tmp397 +- tmp396
print tmp398
tmp399 = tmp398 +- tmp397
print tmp399
tmp400 = tmp399 +- tmp398
print tmp400
tmp401 = tmp400 +- tmp399
print tmp401
tmp402 = tmp401 +- tmp400
print tmp402
tmp403 = tmp402 +- tmp401
print tmp403
tmp404 = tmp403 +- tmp402
print tmp404
tmp405 = tmp404 +- tmp403
print tmp405
tmp406 = tmp405 +- tmp404
print tmp406
tmp407 = tmp406 +- tmp405
print tmp407
tmp408 = tmp407 +- tmp406
print tmp408
tmp409 = tmp408 +- tmp407
print tmp409
tmp410 = tmp409 +- tmp408
print tmp410
tmp411 = tmp410 +- tmp409
print tmp411
tmp412 = tmp411 +- tmp410
print tmp412
tmp413 = tmp412 +- tmp411
print tmp413
tmp414 = tmp413 +- tmp412
print tmp414
tmp415 = tmp414 +- tmp413
print tmp415
tmp416 = tmp415 +- tmp414
print tmp416
tmp417 = tmp416 +- tmp415
print tmp417
tmp418 = tmp417 +- tmp416
print tmp418
tmp419 = tmp418 +- tmp417
print tmp419
tmp420 = tmp419 +- tmp418
print tmp420
tmp421 = tmp420 +- tmp419
print tmp421
tmp422 = tmp421 +- tmp420
print tmp422
tmp423 = tmp422 +- tmp421
print tmp423
tmp424 = tmp423 +- tmp422
print tmp424
tmp425 = tmp424 +- tmp423
print tmp425
tmp426 = tmp425 +- tmp424
print tmp426
tmp427 = tmp426 +- tmp425
print tmp427
tmp428 = tmp427 +- tmp426
print tmp428
tmp429 = tmp428 +- tmp427
print tmp429
tmp430 = tmp429 +- tmp428
print tmp430
tmp431 = tmp430 +- tmp429
print tmp431
tmp432 = tmp431 +- tmp430
print tmp432
tmp433 = tmp432 +- tmp431
print tmp433
tmp434 = tmp433 +- tmp432
print tmp434
tmp435 = tmp434 +- tmp433
print tmp435
tmp436 = tmp435 +- tmp434
print tmp436
tmp437 = tmp436 +- tmp435
print tmp437
tmp438 = tmp437 +- tmp436
print tmp438
tmp439 = tmp438 +- tmp437
print tmp439
tmp440 = tmp439 +- tmp438
print tmp440
tmp441 = tmp440 +- tmp439
print tmp441
tmp442 = tmp441 +- tmp440
print tmp442
tmp443 = tmp442 +- tmp441
print tmp443
tmp444 = tmp443 +- tmp442
print tmp444
tmp445 = tmp444 +- tmp443
print tmp445
tmp446 = tmp445 +- tmp444
print tmp446
tmp447 = tmp446 +- tmp445
print tmp447
tmp448 = tmp447 +- tmp446
print tmp448
tmp449 = tmp448 +- tmp447
print tmp449
tmp450 = tmp449 +- tmp448
print tmp450
tmp451 = tmp450 +- tmp449
print tmp451
tmp452 = tmp451 +- tmp450
print tmp452
tmp453 = tmp452 +- tmp451
print tmp453
tmp454 = tmp453 +- tmp452
print tmp454
tmp455 = tmp454 +- tmp453
print tmp455
tmp456 = tmp455 +- tmp454
print tmp456
tmp457 = tmp456 +- tmp455
print tmp457
tmp458 = tmp457 +- tmp456
print tmp458
tmp459 = tmp458 +- tmp457
print tmp459
tmp460 = tmp459 +- tmp458
print tmp460
tmp461 = tmp460 +- tmp459
print tmp461
tmp462 = tmp461 +- tmp460
print tmp462
tmp463 = tmp462 +- tmp461
print tmp463
tmp464 = tmp463 +- tmp462
print tmp464
tmp465 = tmp464 +- tmp463
print tmp465
tmp466 = tmp465 +- tmp464
print tmp466
tmp467 = tmp466 +- tmp465
print tmp467
tmp468 = tmp467 +- tmp466
print tmp468
tmp469 = tmp468 +- tmp467
print tmp469
tmp470 = tmp469 +- tmp468
print tmp470
tmp471 = tmp470 +- tmp469
print tmp471
tmp472 = tmp471 +- tmp470
print tmp472
tmp473 = tmp472 +- tmp471
print tmp473
tmp474 = tmp473 +- tmp472
print tmp474
tmp475 = tmp474 +- tmp473
print tmp475
tmp476 = tmp475 +- tmp474
print tmp476
tmp477 = tmp476 +- tmp475
print tmp477
tmp478 = tmp477 +- tmp476
print tmp478
tmp479 = tmp478 +- tmp477
print tmp479
tmp480 = tmp479 +- tmp478
print tmp480
tmp481 = tmp480 +- tmp479
print tmp481
tmp482 = tmp481 +- tmp480
print tmp482
tmp483 = tmp482 +- tmp481
print tmp483
tmp484 = tmp483 +- tmp482
print tmp484
tmp485 = tmp484 +- tmp483
print tmp485
tmp486 = tmp485 +- tmp484
print tmp486
tmp487 = tmp486 +- tmp485
print tmp487
tmp488 = tmp487 +- tmp486
print tmp488
tmp489 = tmp488 +- tmp487
print tmp489
tmp490 = tmp489 +- tmp488
print tmp490
tmp491 = tmp490 +- tmp489
print tmp491
tmp492 = tmp491 +- tmp490
print tmp492
tmp493 = tmp492 +- tmp491
print tmp493
tmp494 = tmp493 +- tmp492
print tmp494
tmp495 = tmp494 +- tmp493
print tmp495
tmp496 = tmp495 +- tmp494
print tmp496
tmp497 = tmp496 +- tmp495
print tmp497
tmp498 = tmp497 +- tmp496
print tmp498
tmp499 = tmp498 +- tmp497
print tmp499
tmp500 = tmp499 +- tmp498
print tmp500
tmp501 = tmp500 +- tmp499
print tmp501
tmp502 = tmp501 +- tmp500
print tmp502
tmp503 = tmp502 +- tmp501
print tmp503
tmp504 = tmp503 +- tmp502
print tmp504
tmp505 = tmp504 +- tmp503
print tmp505
tmp506 = tmp505 +- tmp504
print tmp506
tmp507 = tmp506 +- tmp505
print tmp507
tmp508 = tmp507 +- tmp506
print tmp508
tmp509 = tmp508 +- tmp507
print tmp509
tmp510 = tmp509 +- tmp508
print tmp510
tmp511 = tmp510 +- tmp509
print tmp511
tmp512 = tmp511 +- tmp510
print tmp512
tmp513 = tmp512 +- tmp511
print tmp513
tmp514 = tmp513 +- tmp512
print tmp514
tmp515 = tmp514 +- tmp513
print tmp515
tmp516 = tmp515 +- tmp514
print tmp516
tmp517 = tmp516 +- tmp515
print tmp517
tmp518 = tmp517 +- tmp516
print tmp518
tmp519 = tmp518 +- tmp517
print tmp519
tmp520 = tmp519 +- tmp518
print tmp520
tmp521 = tmp520 +- tmp519
print tmp521
tmp522 = tmp521 +- tmp520
print tmp522
tmp523 = tmp522 +- tmp521
print tmp523
tmp524 = tmp523 +- tmp522
print tmp524
tmp525 = tmp524 +- tmp523
print tmp525
tmp526 = tmp525 +- tmp524
print tmp526
tmp527 = tmp526 +- tmp525
print tmp527
tmp528 = tmp527 +- tmp526
print tmp528
tmp529 = tmp528 +- tmp527
print tmp529
tmp530 = tmp529 +- tmp528
print tmp530
tmp531 = tmp530 +- tmp529
print tmp531
tmp532 = tmp531 +- tmp530
print tmp532
tmp533 = tmp532 +- tmp531
print tmp533
tmp534 = tmp533 +- tmp532
print tmp534
tmp535 = tmp534 +- tmp533
print tmp535
tmp536 = tmp535 +- tmp534
print tmp536
tmp537 = tmp536 +- tmp535
print tmp537
tmp538 = tmp537 +- tmp536
print tmp538
tmp539 = tmp538 +- tmp537
print tmp539
tmp540 = tmp539 +- tmp538
print tmp540
tmp541 = tmp540 +- tmp539
print tmp541
tmp542 = tmp541 +- tmp540
print tmp542
tmp543 = tmp542 +- tmp541
print tmp543
tmp544 = tmp543 +- tmp542
print tmp544
tmp545 = tmp544 +- tmp543
print tmp545
tmp546 = tmp545 +- tmp544
print tmp546
tmp547 = tmp546 +- tmp545
print tmp547
tmp548 = tmp547 +- tmp546
print tmp548
tmp549 = tmp548 +- tmp547
print tmp549
tmp550 = tmp549 +- tmp548
print tmp550
tmp551 = tmp550 +- tmp549
print tmp551
tmp552 = tmp551 +- tmp550
print tmp552
tmp553 = tmp552 +- tmp551
print tmp553
tmp554 = tmp553 +- tmp552
print tmp554
tmp555 = tmp554 +- tmp553
print tmp555
tmp556 = tmp555 +- tmp554
print tmp556
tmp557 = tmp556 +- tmp555
print tmp557
tmp558 = tmp557 +- tmp556
print tmp558
tmp559 = tmp558 +- tmp557
print tmp559
tmp560 = tmp559 +- tmp558
print tmp560
tmp561 = tmp560 +- tmp559
print tmp561
tmp562 = tmp561 +- tmp560
print tmp562
tmp563 = tmp562 +- tmp561
print tmp563
tmp564 = tmp563 +- tmp562
print tmp564
tmp565 = tmp564 +- tmp563
print tmp565
tmp566 = tmp565 +- tmp564
print tmp566
tmp567 = tmp566 +- tmp565
print tmp567
tmp568 = tmp567 +- tmp566
print tmp568
tmp569 = tmp568 +- tmp567
print tmp569
tmp570 = tmp569 +- tmp568
print tmp570
tmp571 = tmp570 +- tmp569
print tmp571
tmp572 = tmp571 +- tmp570
print tmp572
tmp573 = tmp572 +- tmp571
print tmp573
tmp574 = tmp573 +- tmp572
print tmp574
tmp575 = tmp574 +- tmp573
print tmp575
tmp576 = tmp575 +- tmp574
print tmp576
tmp577 = tmp576 +- tmp575
print tmp577
tmp578 = tmp577 +- tmp576
print tmp578
tmp579 = tmp578 +- tmp577
print tmp579
tmp580 = tmp579 +- tmp578
print tmp580
tmp581 = tmp580 +- tmp579
print tmp581
tmp582 = tmp581 +- tmp580
print tmp582
tmp583 = tmp582 +- tmp581
print tmp583
tmp584 = tmp583 +- tmp582
print tmp584
tmp585 = tmp584 +- tmp583
print tmp585
tmp586 = tmp585 +- tmp584
print tmp586
tmp587 = tmp586 +- tmp585
print tmp587
tmp588 = tmp587 +- tmp586
print tmp588
tmp589 = tmp588 +- tmp587
print tmp589
tmp590 = tmp589 +- tmp588
print tmp590
tmp591 = tmp590 +- tmp589
print tmp591
tmp592 = tmp591 +- tmp590
print tmp592
tmp593 = tmp592 +- tmp591
print tmp593
tmp594 = tmp593 +- tmp592
print tmp594
tmp595 = tmp594 +- tmp593
print tmp595
tmp596 = tmp595 +- tmp594
print tmp596
tmp597 = tmp596 +- tmp595
print tmp597
tmp598 = tmp597 +- tmp596
print tmp598
tmp599 = tmp598 +- tmp597
print tmp599
tmp600 = tmp599 +- tmp598
print tmp600
tmp601 = tmp600 +- tmp599
print tmp601
tmp602 = tmp601 +- tmp600
print tmp602
tmp603 = tmp602 +- tmp601
print tmp603
tmp604 = tmp603 +- tmp602
print tmp604
tmp605 = tmp604 +- tmp603
print tmp605
tmp606 = tmp605 +- tmp604
print tmp606
tmp607 = tmp606 +- tmp605
print tmp607
tmp608 = tmp607 +- tmp606
print tmp608
tmp609 = tmp608 +- tmp607
print tmp609
tmp610 = tmp609 +- tmp608
print tmp610
tmp611 = tmp610 +- tmp609
print tmp611
tmp612 = tmp611 +- tmp610
print tmp612
tmp613 = tmp612 +- tmp611
print tmp613
tmp614 = tmp613 +- tmp612
print tmp614
tmp615 = tmp614 +- tmp613
print tmp615
tmp616 = tmp615 +- tmp614
print tmp616
tmp617 = tmp616 +- tmp615
print tmp617
tmp618 = tmp617 +- tmp616
print tmp618
tmp619 = tmp618 +- tmp617
print tmp619
tmp620 = tmp619 +- tmp618
print tmp620
tmp621 = tmp620 +- tmp619
print tmp621
tmp622 = tmp621 +- tmp620
print tmp622
tmp623 = tmp622 +- tmp621
print tmp623
tmp624 = tmp623 +- tmp622
print tmp624
tmp625 = tmp624 +- tmp623
print tmp625
tmp626 = tmp625 +- tmp624
print tmp626
tmp627 = tmp626 +- tmp625
print tmp627
tmp628 = tmp627 +- tmp626
print tmp628
tmp629 = tmp628 +- tmp627
print tmp629
tmp630 = tmp629 +- tmp628
print tmp630
tmp631 = tmp630 +- tmp629
print tmp631
tmp632 = tmp631 +- tmp630
print tmp632
tmp633 = tmp632 +- tmp631
print tmp633
tmp634 = tmp633 +- tmp632
print tmp634
tmp635 = tmp634 +- tmp633
print tmp635
tmp636 = tmp635 +- tmp634
print tmp636
tmp637 = tmp636 +- tmp635
print tmp637
tmp638 = tmp637 +- tmp636
print tmp638
tmp639 = tmp638 +- tmp637
print tmp639
tmp640 = tmp639 +- tmp638
print tmp640
tmp641 = tmp640 +- tmp639
print tmp641
tmp642 = tmp641 +- tmp640
print tmp642
tmp643 = tmp642 +- tmp641
print tmp643
tmp644 = tmp643 +- tmp642
print tmp644
tmp645 = tmp644 +- tmp643
print tmp645
tmp646 = tmp645 +- tmp644
print tmp646
tmp647 = tmp646 +- tmp645
print tmp647
tmp648 = tmp647 +- tmp646
print tmp648
tmp649 = tmp648 +- tmp647
print tmp649
tmp650 = tmp649 +- tmp648
print tmp650
tmp651 = tmp650 +- tmp649
print tmp651
tmp652 = tmp651 +- tmp650
print tmp652
tmp653 = tmp652 +- tmp651
print tmp653
tmp654 = tmp653 +- tmp652
print tmp654
tmp655 = tmp654 +- tmp653
print tmp655
tmp656 = tmp655 +- tmp654
print tmp656
tmp657 = tmp656 +- tmp655
print tmp657
tmp658 = tmp657 +- tmp656
print tmp658
tmp659 = tmp658 +- tmp657
print tmp659
tmp660 = tmp659 +- tmp658
print tmp660
tmp661 = tmp660 +- tmp659
print tmp661
tmp662 = tmp661 +- tmp660
print tmp662
tmp663 = tmp662 +- tmp661
print tmp663
tmp664 = tmp663 +- tmp662
print tmp664
tmp665 = tmp664 +- tmp663
print tmp665
tmp666 = tmp665 +- tmp664
print tmp666
tmp667 = tmp666 +- tmp665
print tmp667
tmp668 = tmp667 +- tmp666
print tmp668
tmp669 = tmp668 +- tmp667
print tmp669
tmp670 = tmp669 +- tmp668
print tmp670
tmp671 = tmp670 +- tmp669
print tmp671
tmp672 = tmp671 +- tmp670
print tmp672
tmp673 = tmp672 +- tmp671
print tmp673
tmp674 = tmp673 +- tmp672
print tmp674
tmp675 = tmp674 +- tmp673
print tmp675
tmp676 = tmp675 +- tmp674
print tmp676
tmp677 = tmp676 +- tmp675
print tmp677
tmp678 = tmp677 +- tmp676
print tmp678
tmp679 = tmp678 +- tmp677
print tmp679
tmp680 = tmp679 +- tmp678
print tmp680
tmp681 = tmp680 +- tmp679
print tmp681
tmp682 = tmp681 +- tmp680
print tmp682
tmp683 = tmp682 +- tmp681
print tmp683
tmp684 = tmp683 +- tmp682
print tmp684
tmp685 = tmp684 +- tmp683
print tmp685
tmp686 = tmp685 +- tmp684
print tmp686
tmp687 = tmp686 +- tmp685
print tmp687
tmp688 = tmp687 +- tmp686
print tmp688
tmp689 = tmp688 +- tmp687
print tmp689
tmp690 = tmp689 +- tmp688
print tmp690
tmp691 = tmp690 +- tmp689
print tmp691
tmp692 = tmp691 +- tmp690
print tmp692
tmp693 = tmp692 +- tmp691
print tmp693
tmp694 = tmp693 +- tmp692
print tmp694
tmp695 = tmp694 +- tmp693
print tmp695
tmp696 = tmp695 +- tmp694
print tmp696
tmp697 = tmp696 +- tmp695
print tmp697
tmp698 = tmp697 +- tmp696
print tmp698
tmp699 = tmp698 +- tmp697
print tmp699
tmp700 = tmp699 +- tmp698
print tmp700
tmp701 = tmp700 +- tmp699
print tmp701
tmp702 = tmp701 +- tmp700
print tmp702
tmp703 = tmp702 +- tmp701
print tmp703
tmp704 = tmp703 +- tmp702
print tmp704
tmp705 = tmp704 +- tmp703
print tmp705
tmp706 = tmp705 +- tmp704
print tmp706
tmp707 = tmp706 +- tmp705
print tmp707
tmp708 = tmp707 +- tmp706
print tmp708
tmp709 = tmp708 +- tmp707
print tmp709
tmp710 = tmp709 +- tmp708
print tmp710
tmp711 = tmp710 +- tmp709
print tmp711
tmp712 = tmp711 +- tmp710
print tmp712
tmp713 = tmp712 +- tmp711
print tmp713
tmp714 = tmp713 +- tmp712
print tmp714
tmp715 = tmp714 +- tmp713
print tmp715
tmp716 = tmp715 +- tmp714
print tmp716
tmp717 = tmp716 +- tmp715
print tmp717
tmp718 = tmp717 +- tmp716
print tmp718
tmp719 = tmp718 +- tmp717
print tmp719
tmp720 = tmp719 +- tmp718
print tmp720
tmp721 = tmp720 +- tmp719
print tmp721
tmp722 = tmp721 +- tmp720
print tmp722
tmp723 = tmp722 +- tmp721
print tmp723
tmp724 = tmp723 +- tmp722
print tmp724
tmp725 = tmp724 +- tmp723
print tmp725
tmp726 = tmp725 +- tmp724
print tmp726
tmp727 = tmp726 +- tmp725
print tmp727
tmp728 = tmp727 +- tmp726
print tmp728
tmp729 = tmp728 +- tmp727
print tmp729
tmp730 = tmp729 +- tmp728
print tmp730
tmp731 = tmp730 +- tmp729
print tmp731
tmp732 = tmp731 +- tmp730
print tmp732
tmp733 = tmp732 +- tmp731
print tmp733
tmp734 = tmp733 +- tmp732
print tmp734
tmp735 = tmp734 +- tmp733
print tmp735
tmp736 = tmp735 +- tmp734
print tmp736
tmp737 = tmp736 +- tmp735
print tmp737
tmp738 = tmp737 +- tmp736
print tmp738
tmp739 = tmp738 +- tmp737
print tmp739
tmp740 = tmp739 +- tmp738
print tmp740
tmp741 = tmp740 +- tmp739
print tmp741
tmp742 = tmp741 +- tmp740
print tmp742
tmp743 = tmp742 +- tmp741
print tmp743
tmp744 = tmp743 +- tmp742
print tmp744
tmp745 = tmp744 +- tmp743
print tmp745
tmp746 = tmp745 +- tmp744
print tmp746
tmp747 = tmp746 +- tmp745
print tmp747
tmp748 = tmp747 +- tmp746
print tmp748
tmp749 = tmp748 +- tmp747
print tmp749
tmp750 = tmp749 +- tmp748
print tmp750
tmp751 = tmp750 +- tmp749
print tmp751
tmp752 = tmp751 +- tmp750
print tmp752
tmp753 = tmp752 +- tmp751
print tmp753
tmp754 = tmp753 +- tmp752
print tmp754
tmp755 = tmp754 +- tmp753
print tmp755
tmp756 = tmp755 +- tmp754
print tmp756
tmp757 = tmp756 +- tmp755
print tmp757
tmp758 = tmp757 +- tmp756
print tmp758
tmp759 = tmp758 +- tmp757
print tmp759
tmp760 = tmp759 +- tmp758
print tmp760
tmp761 = tmp760 +- tmp759
print tmp761
tmp762 = tmp761 +- tmp760
print tmp762
tmp763 = tmp762 +- tmp761
print tmp763
tmp764 = tmp763 +- tmp762
print tmp764
tmp765 = tmp764 +- tmp763
print tmp765
tmp766 = tmp765 +- tmp764
print tmp766
tmp767 = tmp766 +- tmp765
print tmp767
tmp768 = tmp767 +- tmp766
print tmp768
tmp769 = tmp768 +- tmp767
print tmp769
tmp770 = tmp769 +- tmp768
print tmp770
tmp771 = tmp770 +- tmp769
print tmp771
tmp772 = tmp771 +- tmp770
print tmp772
tmp773 = tmp772 +- tmp771
print tmp773
tmp774 = tmp773 +- tmp772
print tmp774
tmp775 = tmp774 +- tmp773
print tmp775
tmp776 = tmp775 +- tmp774
print tmp776
tmp777 = tmp776 +- tmp775
print tmp777
tmp778 = tmp777 +- tmp776
print tmp778
tmp779 = tmp778 +- tmp777
print tmp779
tmp780 = tmp779 +- tmp778
print tmp780
tmp781 = tmp780 +- tmp779
print tmp781
tmp782 = tmp781 +- tmp780
print tmp782
tmp783 = tmp782 +- tmp781
print tmp783
tmp784 = tmp783 +- tmp782
print tmp784
tmp785 = tmp784 +- tmp783
print tmp785
tmp786 = tmp785 +- tmp784
print tmp786
tmp787 = tmp786 +- tmp785
print tmp787
tmp788 = tmp787 +- tmp786
print tmp788
tmp789 = tmp788 +- tmp787
print tmp789
tmp790 = tmp789 +- tmp788
print tmp790
tmp791 = tmp790 +- tmp789
print tmp791
tmp792 = tmp791 +- tmp790
print tmp792
tmp793 = tmp792 +- tmp791
print tmp793
tmp794 = tmp793 +- tmp792
print tmp794
tmp795 = tmp794 +- tmp793
print tmp795
tmp796 = tmp795 +- tmp794
print tmp796
tmp797 = tmp796 +- tmp795
print tmp797
tmp798 = tmp797 +- tmp796
print tmp798
tmp799 = tmp798 +- tmp797
print tmp799
tmp800 = tmp799 +- tmp798
print tmp800
tmp801 = tmp800 +- tmp799
print tmp801
tmp802 = tmp801 +- tmp800
print tmp802
tmp803 = tmp802 +- tmp801
print tmp803
tmp804 = tmp803 +- tmp802
print tmp804
tmp805 = tmp804 +- tmp803
print tmp805
tmp806 = tmp805 +- tmp804
print tmp806
tmp807 = tmp806 +- tmp805
print tmp807
tmp808 = tmp807 +- tmp806
print tmp808
tmp809 = tmp808 +- tmp807
print tmp809
tmp810 = tmp809 +- tmp808
print tmp810
tmp811 = tmp810 +- tmp809
print tmp811
tmp812 = tmp811 +- tmp810
print tmp812
tmp813 = tmp812 +- tmp811
print tmp813
tmp814 = tmp813 +- tmp812
print tmp814
tmp815 = tmp814 +- tmp813
print tmp815
tmp816 = tmp815 +- tmp814
print tmp816
tmp817 = tmp816 +- tmp815
print tmp817
tmp818 = tmp817 +- tmp816
print tmp818
tmp819 = tmp818 +- tmp817
print tmp819
tmp820 = tmp819 +- tmp818
print tmp820
tmp821 = tmp820 +- tmp819
print tmp821
tmp822 = tmp821 +- tmp820
print tmp822
tmp823 = tmp822 +- tmp821
print tmp823
tmp824 = tmp823 +- tmp822
print tmp824
tmp825 = tmp824 +- tmp823
print tmp825
tmp826 = tmp825 +- tmp824
print tmp826
tmp827 = tmp826 +- tmp825
print tmp827
tmp828 = tmp827 +- tmp826
print tmp828
tmp829 = tmp828 +- tmp827
print tmp829
tmp830 = tmp829 +- tmp828
print tmp830
tmp831 = tmp830 +- tmp829
print tmp831
tmp832 = tmp831 +- tmp830
print tmp832
tmp833 = tmp832 +- tmp831
print tmp833
tmp834 = tmp833 +- tmp832
print tmp834
tmp835 = tmp834 +- tmp833
print tmp835
tmp836 = tmp835 +- tmp834
print tmp836
tmp837 = tmp836 +- tmp835
print tmp837
tmp838 = tmp837 +- tmp836
print tmp838
tmp839 = tmp838 +- tmp837
print tmp839
tmp840 = tmp839 +- tmp838
print tmp840
tmp841 = tmp840 +- tmp839
print tmp841
tmp842 = tmp841 +- tmp840
print tmp842
tmp843 = tmp842 +- tmp841
print tmp843
tmp844 = tmp843 +- tmp842
print tmp844
tmp845 = tmp844 +- tmp843
print tmp845
tmp846 = tmp845 +- tmp844
print tmp846
tmp847 = tmp846 +- tmp845
print tmp847
tmp848 = tmp847 +- tmp846
print tmp848
tmp849 = tmp848 +- tmp847
print tmp849
tmp850 = tmp849 +- tmp848
print tmp850
tmp851 = tmp850 +- tmp849
print tmp851
tmp852 = tmp851 +- tmp850
print tmp852
tmp853 = tmp852 +- tmp851
print tmp853
tmp854 = tmp853 +- tmp852
print tmp854
tmp855 = tmp854 +- tmp853
print tmp855
tmp856 = tmp855 +- tmp854
print tmp856
tmp857 = tmp856 +- tmp855
print tmp857
tmp858 = tmp857 +- tmp856
print tmp858
tmp859 = tmp858 +- tmp857
print tmp859
tmp860 = tmp859 +- tmp858
print tmp860
tmp861 = tmp860 +- tmp859
print tmp861
tmp862 = tmp861 +- tmp860
print tmp862
tmp863 = tmp862 +- tmp861
print tmp863
tmp864 = tmp863 +- tmp862
print tmp864
tmp865 = tmp864 +- tmp863
print tmp865
tmp866 = tmp865 +- tmp864
print tmp866
tmp867 = tmp866 +- tmp865
print tmp867
tmp868 = tmp867 +- tmp866
print tmp868
tmp869 = tmp868 +- tmp867
print tmp869
tmp870 = tmp869 +- tmp868
print tmp870
tmp871 = tmp870 +- tmp869
print tmp871
tmp872 = tmp871 +- tmp870
print tmp872
tmp873 = tmp872 +- tmp871
print tmp873
tmp874 = tmp873 +- tmp872
print tmp874
tmp875 = tmp874 +- tmp873
print tmp875
tmp876 = tmp875 +- tmp874
print tmp876
tmp877 = tmp876 +- tmp875
print tmp877
tmp878 = tmp877 +- tmp876
print tmp878
tmp879 = tmp878 +- tmp877
print tmp879
tmp880 = tmp879 +- tmp878
print tmp880
tmp881 = tmp880 +- tmp879
print tmp881
tmp882 = tmp881 +- tmp880
print tmp882
tmp883 = tmp882 +- tmp881
print tmp883
tmp884 = tmp883 +- tmp882
print tmp884
tmp885 = tmp884 +- tmp883
print tmp885
tmp886 = tmp885 +- tmp884
print tmp886
tmp887 = tmp886 +- tmp885
print tmp887
tmp888 = tmp887 +- tmp886
print tmp888
tmp889 = tmp888 +- tmp887
print tmp889
tmp890 = tmp889 +- tmp888
print tmp890
tmp891 = tmp890 +- tmp889
print tmp891
tmp892 = tmp891 +- tmp890
print tmp892
tmp893 = tmp892 +- tmp891
print tmp893
tmp894 = tmp893 +- tmp892
print tmp894
tmp895 = tmp894 +- tmp893
print tmp895
tmp896 = tmp895 +- tmp894
print tmp896
tmp897 = tmp896 +- tmp895
print tmp897
tmp898 = tmp897 +- tmp896
print tmp898
tmp899 = tmp898 +- tmp897
print tmp899
tmp900 = tmp899 +- tmp898
print tmp900
tmp901 = tmp900 +- tmp899
print tmp901
tmp902 = tmp901 +- tmp900
print tmp902
tmp903 = tmp902 +- tmp901
print tmp903
tmp904 = tmp903 +- tmp902
print tmp904
tmp905 = tmp904 +- tmp903
print tmp905
tmp906 = tmp905 +- tmp904
print tmp906
tmp907 = tmp906 +- tmp905
print tmp907
tmp908 = tmp907 +- tmp906
print tmp908
tmp909 = tmp908 +- tmp907
print tmp909
tmp910 = tmp909 +- tmp908
print tmp910
tmp911 = tmp910 +- tmp909
print tmp911
tmp912 = tmp911 +- tmp910
print tmp912
tmp913 = tmp912 +- tmp911
print tmp913
tmp914 = tmp913 +- tmp912
print tmp914
tmp915 = tmp914 +- tmp913
print tmp915
tmp916 = tmp915 +- tmp914
print tmp916
tmp917 = tmp916 +- tmp915
print tmp917
tmp918 = tmp917 +- tmp916
print tmp918
tmp919 = tmp918 +- tmp917
print tmp919
tmp920 = tmp919 +- tmp918
print tmp920
tmp921 = tmp920 +- tmp919
print tmp921
tmp922 = tmp921 +- tmp920
print tmp922
tmp923 = tmp922 +- tmp921
print tmp923
tmp924 = tmp923 +- tmp922
print tmp924
tmp925 = tmp924 +- tmp923
print tmp925
tmp926 = tmp925 +- tmp924
print tmp926
tmp927 = tmp926 +- tmp925
print tmp927
tmp928 = tmp927 +- tmp926
print tmp928
tmp929 = tmp928 +- tmp927
print tmp929
tmp930 = tmp929 +- tmp928
print tmp930
tmp931 = tmp930 +- tmp929
print tmp931
tmp932 = tmp931 +- tmp930
print tmp932
tmp933 = tmp932 +- tmp931
print tmp933
tmp934 = tmp933 +- tmp932
print tmp934
tmp935 = tmp934 +- tmp933
print tmp935
tmp936 = tmp935 +- tmp934
print tmp936
tmp937 = tmp936 +- tmp935
print tmp937
tmp938 = tmp937 +- tmp936
print tmp938
tmp939 = tmp938 +- tmp937
print tmp939
tmp940 = tmp939 +- tmp938
print tmp940
tmp941 = tmp940 +- tmp939
print tmp941
tmp942 = tmp941 +- tmp940
print tmp942
tmp943 = tmp942 +- tmp941
print tmp943
tmp944 = tmp943 +- tmp942
print tmp944
tmp945 = tmp944 +- tmp943
print tmp945
tmp946 = tmp945 +- tmp944
print tmp946
tmp947 = tmp946 +- tmp945
print tmp947
tmp948 = tmp947 +- tmp946
print tmp948
tmp949 = tmp948 +- tmp947
print tmp949
tmp950 = tmp949 +- tmp948
print tmp950
tmp951 = tmp950 +- tmp949
print tmp951
tmp952 = tmp951 +- tmp950
print tmp952
tmp953 = tmp952 +- tmp951
print tmp953
tmp954 = tmp953 +- tmp952
print tmp954
tmp955 = tmp954 +- tmp953
print tmp955
tmp956 = tmp955 +- tmp954
print tmp956
tmp957 = tmp956 +- tmp955
print tmp957
tmp958 = tmp957 +- tmp956
print tmp958
tmp959 = tmp958 +- tmp957
print tmp959
tmp960 = tmp959 +- tmp958
print tmp960
tmp961 = tmp960 +- tmp959
print tmp961
tmp962 = tmp961 +- tmp960
print tmp962
tmp963 = tmp962 +- tmp961
print tmp963
tmp964 = tmp963 +- tmp962
print tmp964
tmp965 = tmp964 +- tmp963
print tmp965
tmp966 = tmp965 +- tmp964
print tmp966
tmp967 = tmp966 +- tmp965
print tmp967
tmp968 = tmp967 +- tmp966
print tmp968
tmp969 = tmp968 +- tmp967
print tmp969
tmp970 = tmp969 +- tmp968
print tmp970
tmp971 = tmp970 +- tmp969
print tmp971
tmp972 = tmp971 +- tmp970
print tmp972
tmp973 = tmp972 +- tmp971
print tmp973
tmp974 = tmp973 +- tmp972
print tmp974
tmp975 = tmp974 +- tmp973
print tmp975
tmp976 = tmp975 +- tmp974
print tmp976
tmp977 = tmp976 +- tmp975
print tmp977
tmp978 = tmp977 +- tmp976
print tmp978
tmp979 = tmp978 +- tmp977
print tmp979
tmp980 = tmp979 +- tmp978
print tmp980
tmp981 = tmp980 +- tmp979
print tmp981
tmp982 = tmp981 +- tmp980
print tmp982
tmp983 = tmp982 +- tmp981
print tmp983
tmp984 = tmp983 +- tmp982
print tmp984
tmp985 = tmp984 +- tmp983
print tmp985
tmp986 = tmp985 +- tmp984
print tmp986
tmp987 = tmp986 +- tmp985
print tmp987
tmp988 = tmp987 +- tmp986
print tmp988
tmp989 = tmp988 +- tmp987
print tmp989
tmp990 = tmp989 +- tmp988
print tmp990
tmp991 = tmp990 +- tmp989
print tmp991
tmp992 = tmp991 +- tmp990
print tmp992
tmp993 = tmp992 +- tmp991
print tmp993
tmp994 = tmp993 +- tmp992
print tmp994
tmp995 = tmp994 +- tmp993
print tmp995
tmp996 = tmp995 +- tmp994
print tmp996
tmp997 = tmp996 +- tmp995
print tmp997
tmp998 = tmp997 +- tmp996
print tmp998
tmp999 = tmp998 +- tmp997
print tmp999

