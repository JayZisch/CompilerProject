

print 42

