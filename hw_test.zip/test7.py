-(-(5 + -7) + (-(-5 + 7) + (3+-4+-input())))
print input()
