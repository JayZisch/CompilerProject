
a = -10
b = 2
c = 2
c + 2
x = 0
y = 4
z = - b + y + - a + - input() + x
print input() + z


