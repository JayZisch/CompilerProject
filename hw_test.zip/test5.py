
v=input()
input()
print -input() + input() + (input() + -input()) + input() + -(input() + input())
input()
print input() + (-input() + (input()+(-input()+input())))
input()
