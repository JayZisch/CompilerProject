print_int_nl = 42
print print_int_nl
